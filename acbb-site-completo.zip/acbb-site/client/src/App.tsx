import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { SiteProvider } from "./contexts/SiteContext";
import Navigation from "./components/Navigation";
import Footer from "./components/Footer";

// Pages
import Home from "./pages/Home";
import Noticias from "./pages/Noticias";
import Sobre from "./pages/Sobre";
import Ouvidoria from "./pages/Ouvidoria";
import ConhecaBenevente from "./pages/ConhecaBenevente";

import Diretoria from "./pages/Diretoria";
import Estatuto from "./pages/Estatuto";
import Transparencia from "./pages/Transparencia";
import Mapa from "./pages/Mapa";
import Gestao from "./pages/Gestao";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/noticias"} component={Noticias} />
      <Route path={"/sobre"} component={Sobre} />
      <Route path={"/ouvidoria"} component={Ouvidoria} />
      <Route path={"/conheca-benevente"} component={ConhecaBenevente} />

      <Route path={"/diretoria"} component={Diretoria} />
      <Route path={"/estatuto"} component={Estatuto} />
      <Route path={"/transparencia"} component={Transparencia} />
      <Route path={"/mapa"} component={Mapa} />
      <Route path={"/gestao"} component={Gestao} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <SiteProvider>
        <ThemeProvider defaultTheme="light">
          <TooltipProvider>
            <Toaster />
            <div className="flex flex-col min-h-screen">
              <Navigation />
              <main className="flex-grow">
                <Router />
              </main>
              <Footer />
            </div>
          </TooltipProvider>
        </ThemeProvider>
      </SiteProvider>
    </ErrorBoundary>
  );
}

export default App;
