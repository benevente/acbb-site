export default function Footer() {
  return (
    <footer className="bg-gradient-to-b from-black to-gray-950 text-white border-t border-green-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Sobre */}
          <div className="group">
            <h3 className="text-lg font-bold mb-4 text-green-400 group-hover:text-green-300 transition-colors">
              Associação Comunitária
            </h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              Dedicada à preservação do patrimônio cultural e desenvolvimento sustentável de Benevente. Reconhecida como Utilidade Pública pela Lei Estadual nº 12.605/2025.
            </p>
          </div>

          {/* Contato */}
          <div className="group">
            <h3 className="text-lg font-bold mb-4 text-green-400 group-hover:text-green-300 transition-colors">
              Contato
            </h3>
            <ul className="text-gray-400 text-sm space-y-3">
              <li className="hover:text-green-400 transition-colors">
                <strong>Endereço:</strong> RDS Parque do Papagaio, s/n, Benevente - CEP 29.230-000 - Anchieta-ES
              </li>
              <li className="hover:text-green-400 transition-colors">
                <strong>Telefone:</strong> <a href="tel:+5527996938845" className="hover:underline">(27) 996938845</a>
              </li>
              <li className="hover:text-green-400 transition-colors">
                <strong>Email:</strong> <a href="mailto:contato.acbb@outlook.com.br" className="hover:underline">contato.acbb@outlook.com.br</a>
              </li>
              <li className="hover:text-green-400 transition-colors">
                <strong>CNPJ:</strong> 50.477.436/0001-44
              </li>
            </ul>
          </div>

          {/* Links Rápidos */}
          <div className="group">
            <h3 className="text-lg font-bold mb-4 text-green-400 group-hover:text-green-300 transition-colors">
              Redes Sociais
            </h3>
            <ul className="text-gray-400 text-sm space-y-2">
              <li>
                <a href="https://www.instagram.com/eu.amo.benevente?igsh=MTc1d2g2N3pzeW5nbg%3D%3D&utm_source=qr" target="_blank" rel="noopener noreferrer" className="hover:text-green-400 transition-colors hover:translate-x-1 inline-block">
                  → Instagram (@eu.amo.benevente)
                </a>
              </li>
              <li>
                <a href="https://www.facebook.com/share/1F1deGEbDN/?mibextid=wwXIfr" target="_blank" rel="noopener noreferrer" className="hover:text-green-400 transition-colors hover:translate-x-1 inline-block">
                  → Facebook (ACBB Benevente)
                </a>
              </li>
            </ul>
          </div>
          <div className="group">
            <h3 className="text-lg font-bold mb-4 text-green-400 group-hover:text-green-300 transition-colors">
              Links Rápidos
            </h3>
            <ul className="text-gray-400 text-sm space-y-2">
              <li>
                <a href="/sobre" className="hover:text-green-400 transition-colors hover:translate-x-1 inline-block">
                  → Sobre Nós
                </a>
              </li>
              <li>
                <a href="/ouvidoria" className="hover:text-green-400 transition-colors hover:translate-x-1 inline-block">
                  → Ouvidoria
                </a>
              </li>
              <li>
                <a href="/transparencia" className="hover:text-green-400 transition-colors hover:translate-x-1 inline-block">
                  → Transparência
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-green-900/30 pt-8">
          <div className="text-center text-gray-500 text-sm space-y-2">
            <p>
              © 2025 Associação Comunitária do Bairro Benevente. Todos os direitos reservados.
            </p>
            <p>
              Desenvolvido com <span className="text-green-500">💚</span> para a comunidade de Benevente
            </p>
            <p className="text-xs text-gray-600 mt-4">
              Preservando tradições, construindo futuro | Anchieta - Espírito Santo
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
