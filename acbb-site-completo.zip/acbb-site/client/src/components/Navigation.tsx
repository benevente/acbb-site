import { useState } from "react";
import { Link } from "wouter";
import { Menu, X } from "lucide-react";

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { label: "Início", href: "/" },
    { label: "Notícias", href: "/noticias" },
    { label: "Sobre", href: "/sobre" },
    { label: "Conheça Benevente", href: "/conheca-benevente" },
    { label: "Ouvidoria", href: "/ouvidoria" },
    { label: "Diretoria", href: "/diretoria" },
    { label: "Estatuto", href: "/estatuto" },
    { label: "Transparência", href: "/transparencia" },
    { label: "Gestão", href: "/gestao" },
  ];

  return (
    <nav className="fixed top-0 w-full z-50 bg-gradient-to-b from-black to-black/80 backdrop-blur-md border-b border-green-900/30 shadow-2xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <img src="/logo-benevente.png" alt="Benevente" className="h-12 w-auto group-hover:scale-110 transition-transform" />
            <span className="hidden sm:inline text-lg font-bold text-green-400 group-hover:text-green-300 transition-colors">
              Benevente
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex gap-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="px-3 py-2 text-sm font-medium text-gray-300 hover:text-green-400 hover:bg-green-900/20 rounded-md transition-all duration-300 border border-transparent hover:border-green-600/30"
              >
                {item.label}
              </Link>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 rounded-md text-gray-300 hover:text-green-400 hover:bg-green-900/20 transition-colors"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden pb-4 space-y-1 bg-black/50 backdrop-blur-md rounded-lg mt-2">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="block px-3 py-2 text-sm font-medium text-gray-300 hover:text-green-400 hover:bg-green-900/20 rounded-md transition-colors"
                onClick={() => setIsOpen(false)}
              >
                {item.label}
              </Link>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
}
