import { Download, FileText, CheckCircle } from "lucide-react";

export default function Estatuto() {
  return (
    <div className="min-h-screen bg-black pt-20">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-gray-900 to-black py-20">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-0 w-96 h-96 bg-green-900 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-green-800 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Estatuto da ACBB
          </h1>
          <p className="text-xl text-green-300 mb-4">
            Documento Oficial
          </p>
          <p className="text-gray-300 max-w-2xl mx-auto">
            O Estatuto que rege o funcionamento, objetivos, direitos e deveres da Associação Comunitária do Bairro Benevente
          </p>
        </div>
      </section>

      {/* Conteúdo Principal */}
      <section className="relative bg-black py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Download do Estatuto */}
          <div className="bg-gradient-to-br from-green-900/30 to-green-800/10 border border-green-600/60 rounded-xl p-8 mb-20">
            <div className="flex items-start gap-6">
              <FileText className="text-green-500 flex-shrink-0" size={48} />
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-white mb-2">
                  Estatuto Social - ACBB
                </h2>
                <p className="text-gray-300 mb-6">
                  Documento oficial que regulamenta as atividades, objetivos e funcionamento da Associação Comunitária do Bairro Benevente.
                </p>
                <a
                  href="/estatuto.pdf"
                  download
                  className="inline-flex items-center gap-2 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-all duration-300 transform hover:scale-105 font-semibold shadow-lg"
                >
                  <Download size={20} />
                  Baixar Estatuto (PDF)
                </a>
              </div>
            </div>
          </div>

          {/* Utilidade Pública */}
          <div className="bg-gradient-to-br from-green-900/30 to-green-800/10 border border-green-600/60 rounded-xl p-8 mb-20">
            <div className="flex items-start gap-6">
              <CheckCircle className="text-green-500 flex-shrink-0" size={48} />
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-white mb-2">
                  Utilidade Pública
                </h2>
                <p className="text-gray-300 mb-4">
                  Reconhecida como Utilidade Pública pela Lei Estadual nº 12.605/2025.
                </p>
                <a
                  href="https://ioes.dio.es.gov.br/portal/visualizacoes/pdf/10594#/p:9/e:10594?find=12.605"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-all duration-300 transform hover:scale-105 font-semibold shadow-lg"
                >
                  <FileText size={20} />
                  Acessar Lei 12.605/2025
                </a>
              </div>
            </div>
          </div>

          {/* Princípios Fundamentais */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold text-white mb-8 text-center">Princípios Fundamentais</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                {
                  title: "Transparência",
                  desc: "Todas as atividades e decisões da associação são realizadas com transparência e prestação de contas à comunidade",
                },
                {
                  title: "Democracia",
                  desc: "As decisões são tomadas de forma democrática, com participação dos membros e respeito às opiniões divergentes",
                },
                {
                  title: "Inclusão",
                  desc: "A associação busca incluir todos os membros da comunidade, independentemente de origem, gênero ou condição social",
                },
                {
                  title: "Sustentabilidade",
                  desc: "Todas as atividades são planejadas considerando o impacto ambiental e o bem-estar das futuras gerações",
                },
              ].map((principio, idx) => (
                <div
                  key={idx}
                  className="group relative bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-xl border border-green-900/30 hover:border-green-600/60 transition-all duration-300 transform hover:scale-105"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-green-900/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl -z-10"></div>

                  <CheckCircle className="text-green-500 mb-4 group-hover:text-green-400 transition-colors" size={32} />
                  <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-green-400 transition-colors">
                    {principio.title}
                  </h3>
                  <p className="text-gray-400 group-hover:text-gray-300 transition-colors">
                    {principio.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Objetivos Estatutários */}
          <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 border border-green-900/30 rounded-xl p-12 mb-20">
            <h2 className="text-4xl font-bold text-white mb-8">Objetivos Estatutários</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                "Preservar a memória histórica e cultural de Benevente",
                "Promover o desenvolvimento social e econômico da comunidade",
                "Proteger e valorizar o patrimônio ambiental da região",
                "Promover educação ambiental e cultural",
                "Fortalecer os laços comunitários e a identidade local",
                "Desenvolver projetos de turismo sustentável",
              ].map((objetivo, idx) => (
                <div key={idx} className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-600 flex items-center justify-center mt-1">
                    <span className="text-white text-sm font-bold">{idx + 1}</span>
                  </div>
                  <p className="text-gray-300 pt-1">{objetivo}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Estrutura Organizacional */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold text-white mb-8 text-center">Estrutura Organizacional</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {
                  title: "Assembleia Geral",
                  desc: "Órgão supremo da associação, composto por todos os membros. Responsável pelas decisões estratégicas.",
                },
                {
                  title: "Diretoria",
                  desc: "Responsável pela execução das atividades, representação da associação e implementação das decisões.",
                },
                {
                  title: "Conselho Fiscal",
                  desc: "Responsável pela fiscalização das atividades, gestão financeira e transparência das contas.",
                },
              ].map((orgao, idx) => (
                <div
                  key={idx}
                  className="group relative bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-xl border border-green-900/30 hover:border-green-600/60 transition-all duration-300 transform hover:scale-105"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-green-900/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl -z-10"></div>

                  <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-green-400 transition-colors">
                    {orgao.title}
                  </h3>
                  <p className="text-gray-400 group-hover:text-gray-300 transition-colors">
                    {orgao.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Direitos e Deveres */}
          <div className="bg-gradient-to-r from-green-900/20 to-green-800/10 border border-green-900/30 rounded-xl p-12">
            <h2 className="text-4xl font-bold text-white mb-8">Direitos e Deveres dos Membros</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div>
                <h3 className="text-2xl font-bold text-green-400 mb-6">Direitos</h3>
                <ul className="space-y-3">
                  {[
                    "Participar das assembleias gerais",
                    "Votar e ser votado para cargos",
                    "Acessar informações da associação",
                    "Participar de projetos e atividades",
                    "Propor novas iniciativas e projetos",
                  ].map((direito, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-gray-300">
                      <CheckCircle className="text-green-500 flex-shrink-0 mt-1" size={20} />
                      <span>{direito}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-green-400 mb-6">Deveres</h3>
                <ul className="space-y-3">
                  {[
                    "Cumprir o estatuto e regulamentos",
                    "Participar ativamente das atividades",
                    "Respeitar as decisões coletivas",
                    "Contribuir com recursos quando possível",
                    "Manter sigilo sobre informações confidenciais",
                  ].map((dever, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-gray-300">
                      <CheckCircle className="text-green-500 flex-shrink-0 mt-1" size={20} />
                      <span>{dever}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
