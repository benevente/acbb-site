import { BarChart3, TrendingUp, DollarSign, FileText } from "lucide-react";
import { useSiteContext } from "@/contexts/SiteContext";

export default function Transparencia() {
  const { siteData } = useSiteContext();

  return (
    <div className="min-h-screen bg-black pt-20">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-gray-900 to-black py-20">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-0 w-96 h-96 bg-green-900 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-green-800 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            {siteData.transparenciaTitulo}
          </h1>
          <p className="text-xl text-green-300 mb-4">
            Compromisso com a Comunidade
          </p>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Informações sobre a gestão financeira e atividades da Associação Comunitária do Bairro Benevente
          </p>
        </div>
      </section>

      {/* Conteúdo Principal */}
      <section className="relative bg-black py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Resumo Financeiro */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-20">
            {[
              {
                icon: DollarSign,
                title: "Receita Total",
                valor: `R$ ${siteData.receitaTotal.toLocaleString('pt-BR')}`,
                subtitulo: `Ano ${siteData.anoFinanceiro}`,
                cor: "text-green-500",
              },
              {
                icon: TrendingUp,
                title: "Despesas",
                valor: `R$ ${siteData.despesasTotal.toLocaleString('pt-BR')}`,
                subtitulo: `Ano ${siteData.anoFinanceiro}`,
                cor: "text-blue-500",
              },
              {
                icon: BarChart3,
                title: "Saldo",
                valor: `R$ ${siteData.saldo.toLocaleString('pt-BR')}`,
                subtitulo: "Reserva para projetos",
                cor: "text-purple-500",
              },
            ].map((item, idx) => (
              <div
                key={idx}
                className="group relative bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-xl border border-green-900/30 hover:border-green-600/60 transition-all duration-300 transform hover:scale-105 shadow-2xl hover:shadow-green-900/50"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-green-900/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl -z-10"></div>

                <item.icon className={`${item.cor} mb-4 group-hover:scale-110 transition-transform`} size={40} />
                <h3 className="text-lg font-semibold text-white mb-2">
                  {item.title}
                </h3>
                <p className={`text-3xl font-bold ${item.cor} mb-2`}>
                  {item.valor}
                </p>
                <p className="text-sm text-gray-400">{item.subtitulo}</p>
              </div>
            ))}
          </div>

          {/* Distribuição de Despesas */}
          <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 border border-green-900/30 rounded-xl p-12 mb-20">
            <h2 className="text-4xl font-bold text-white mb-8">Distribuição de Despesas por Categoria</h2>
            <div className="space-y-6">
              {siteData.despesasCategories.map((item, index) => (
                <div key={index}>
                  <div className="flex justify-between mb-3">
                    <span className="font-semibold text-white">{item.categoria}</span>
                    <span className="text-green-400 font-bold">
                      R$ {item.valor.toLocaleString("pt-BR")} ({item.percentual}%)
                    </span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-4 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-green-600 to-green-500 h-4 rounded-full transition-all duration-500 shadow-lg"
                      style={{ width: `${item.percentual}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Fontes de Receita */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold text-white mb-8 text-center">Fontes de Receita</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {siteData.fontesReceita.map((item, index) => (
                <div
                  key={index}
                  className="group relative bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-xl border border-green-900/30 hover:border-green-600/60 transition-all duration-300 transform hover:scale-105"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-green-900/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl -z-10"></div>

                  <h3 className="font-bold text-white mb-3 group-hover:text-green-400 transition-colors">
                    {item.fonte}
                  </h3>
                  <p className="text-3xl font-bold text-green-500 mb-2 group-hover:text-green-400 transition-colors">
                    R$ {item.valor.toLocaleString("pt-BR")}
                  </p>
                  <p className="text-sm text-gray-400">{item.data}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Documentos Disponíveis */}
          <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 border border-green-900/30 rounded-xl p-12 mb-20">
            <h2 className="text-4xl font-bold text-white mb-8">Documentos Disponíveis</h2>
            <div className="space-y-4">
              {siteData.documentos.length === 0 ? (
                <p className="text-gray-400">Nenhum documento disponível no momento</p>
              ) : (
                siteData.documentos.map((doc) => (
                  <div
                    key={doc.id}
                    className="group relative bg-gradient-to-br from-gray-800 to-gray-700 border border-green-900/30 hover:border-green-600/60 rounded-lg p-6 transition-all duration-300 transform hover:scale-102"
                  >
                    <div className="flex justify-between items-center">
                      <div className="flex items-start gap-4">
                        <FileText className="text-green-500 flex-shrink-0 mt-1" size={32} />
                        <div>
                          <h3 className="font-bold text-white mb-1 group-hover:text-green-400 transition-colors">
                            {doc.nome}
                          </h3>
                          <p className="text-sm text-gray-400 group-hover:text-gray-300 transition-colors">
                            {doc.descricao}
                          </p>
                          <p className="text-xs text-gray-500 mt-2">Tipo: {doc.tipo} | Enviado em: {doc.dataUpload}</p>
                        </div>
                      </div>
                      <a
                        href={doc.arquivo}
                        download={doc.nome}
                        className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-all duration-300 transform hover:scale-105 font-semibold whitespace-nowrap ml-4"
                      >
                        Baixar
                      </a>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Histórico de Lançamentos */}
          <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 border border-green-900/30 rounded-xl p-12 mb-20">
            <h2 className="text-4xl font-bold text-white mb-8">Histórico de Lançamentos</h2>
            <div className="space-y-3">
              {siteData.lancamentos.length === 0 ? (
                <p className="text-gray-400">Nenhum lançamento registrado</p>
              ) : (
                siteData.lancamentos.map((lancamento) => (
                  <div key={lancamento.id} className="bg-gray-800 p-4 rounded-lg flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className={`px-3 py-1 rounded text-sm font-semibold ${lancamento.tipo === 'receita' ? 'bg-green-900 text-green-300' : 'bg-red-900 text-red-300'}`}>
                          {lancamento.tipo === 'receita' ? '+' : '-'} R$ {lancamento.valor.toLocaleString('pt-BR')}
                        </span>
                        <span className="text-gray-400 text-sm">{lancamento.data}</span>
                      </div>
                      <p className="text-white font-semibold">{lancamento.descricao}</p>
                      <p className="text-gray-400 text-sm">{lancamento.categoria} {lancamento.observacoes && `- ${lancamento.observacoes}`}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Compromisso com Transparência */}
          <div className="bg-gradient-to-r from-green-900/30 to-green-800/10 border border-green-600/60 rounded-xl p-12">
            <h2 className="text-4xl font-bold text-white mb-6">Nosso Compromisso com Transparência</h2>
            <p className="text-gray-300 leading-relaxed mb-6">
              A ACBB acredita que a transparência é fundamental para manter a confiança da comunidade. Todos os documentos financeiros e relatórios de atividades são disponibilizados publicamente e podem ser consultados a qualquer momento.
            </p>
            <p className="text-gray-300 leading-relaxed mb-6">
              Realizamos prestação de contas regular em assembleias gerais, onde os membros da comunidade podem questionar, sugerir melhorias e participar das decisões sobre o uso dos recursos.
            </p>
            <div className="bg-gray-900/50 p-6 rounded-lg border border-green-900/20">
              <p className="text-green-300 font-semibold mb-2">Para dúvidas ou solicitações de informações adicionais:</p>
              <p className="text-gray-300">
                📧 Email: contato.acbb@outlook.com.br<br />
                📞 Telefone: (27) 996938845
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
