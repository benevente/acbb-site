import { Link } from "wouter";
import { useScroll } from "framer-motion";
import { MapPin, Phone, Mail, Award, ArrowRight, Leaf } from "lucide-react";
import { useSiteContext } from "@/contexts/SiteContext";

export default function Home() {
  const { siteData } = useSiteContext();
  const { scrollY } = useScroll();
  return (
    <div className="min-h-screen bg-black">
      {/* Hero Section com Efeito de Sombra Sofisticado */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background com gradiente e sombra */}
        <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-green-950" style={{ transform: `translateY(${scrollY.get() * 0.5}px)` }}>
          {/* Efeito de sombra em camadas */}
          <div className="absolute inset-0 opacity-40">
            <div className="absolute top-0 left-0 w-96 h-96 bg-gray-900 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
            <div className="absolute bottom-0 right-0 w-96 h-96 bg-gray-800 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
          </div>

          {/* Imagem de fundo com sombra */}
          <div className="absolute inset-0">
            <img
              src="/benevente-area.jpg"
              alt="Benevente"
              className="w-full h-full object-cover opacity-20"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
          </div>
        </div>

        {/* Conteúdo */}
        <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">


          <h1 className="text-6xl md:text-7xl font-bold text-white mb-6 drop-shadow-lg">
            {siteData.homeHeroTitle}
          </h1>

          <p className="text-2xl text-green-500 mb-4 drop-shadow-lg font-light">
            {siteData.homeHeroSubtitle}
          </p>

          <p className="text-lg text-gray-300 mb-12 max-w-2xl mx-auto drop-shadow-lg">
            {siteData.homeHeroDescription}
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/sobre"
              className="group inline-flex items-center gap-2 bg-gradient-to-r from-green-500 to-green-600 text-white px-8 py-4 rounded-lg font-semibold hover:from-green-600 hover:to-green-700 transition-all duration-300 transform hover:scale-105 shadow-2xl"
            >
              Conheça Mais
              <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              href="/noticias"
              className="inline-flex items-center gap-2 border-2 border-green-400 text-green-500 px-8 py-4 rounded-lg font-semibold hover:bg-green-500/10 transition-all duration-300 shadow-lg"
            >
              Notícias
              <ArrowRight size={20} />
            </Link>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="text-green-500 text-sm">Deslize para explorar</div>
        </div>
      </section>

      {/* Informações da Associação */}
      <section className="relative bg-gradient-to-b from-black to-gray-950 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-4 text-white">
            Informações da Associação
          </h2>
          <p className="text-center text-gray-400 mb-16 max-w-2xl mx-auto">
            {siteData.homeInfoDescription}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: MapPin,
                title: "Endereço",
                content: siteData.endereco,
              },
              {
                icon: Phone,
                title: "Telefone",
                content: siteData.telefone,
              },
              {
                icon: Mail,
                title: "Email",
                content: siteData.email,
              },
              {
                icon: Award,
                title: "CNPJ",
                content: siteData.cnpj,
              },
            ].map((item, idx) => (
              <div
                key={idx}
                className="group relative bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-xl border border-gray-700 hover:border-green-500 transition-all duration-500 transform hover:scale-[1.02] shadow-2xl hover:shadow-green-500/50 hover:z-20"
              >
                {/* Sombra sofisticada por trás */}
                <div className="absolute inset-0 bg-gradient-to-br from-green-500/0 to-green-700/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl"></div>

                <div className="relative z-10">
                  <item.icon className="text-green-500 mb-4 group-hover:text-green-400 transition-colors" size={32} />
                  <h3 className="font-bold text-lg text-white mb-2">{item.title}</h3>
                  <p className="text-gray-400 text-sm group-hover:text-gray-300 transition-colors">
                    {item.content}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>



      {/* Seção de Destaques */}
      <section className="relative bg-gradient-to-b from-black to-gray-950/20 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-4 text-white">
            Nossos Projetos
          </h2>
          <p className="text-center text-gray-400 mb-16 max-w-2xl mx-auto">
            Iniciativas que transformam a comunidade e preservam o patrimônio
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
            {
              icon: Leaf,
              title: "Ouvidoria",
              desc: "Sugestões, reclamações, denúncias e elogios da comunidade",
              href: "/ouvidoria",
            },
              {
                icon: MapPin,
                title: "Nossa História",
                desc: "Trajetória da ACBB e compromisso com a comunidade",
                href: "/sobre",
              },
              {
                icon: Award,
                title: "Transparência",
                desc: "Prestação de contas e informações financeiras",
                href: "/transparencia",
              },
            ].map((item, idx) => (
              <Link
                key={idx}
                href={item.href}
                className="group relative bg-gradient-to-br from-gray-900/50 to-gray-800/30 border border-gray-700 p-8 rounded-xl hover:border-green-500 transition-all duration-500 transform hover:scale-[1.02] cursor-pointer hover:z-20"
              >
                {/* Sombra sofisticada por trás */}
                <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-green-700/30 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl -z-10"></div>

                <item.icon className="text-green-500 mb-4 group-hover:text-green-500 transition-colors" size={40} />
                <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-green-500 transition-colors">
                  {item.title}
                </h3>
                <p className="text-gray-400 group-hover:text-gray-300 transition-colors">
                  {item.desc}
                </p>

                <div className="mt-4 flex items-center gap-2 text-green-500 group-hover:text-green-400 transition-colors">
                  <span className="text-sm font-semibold">Saiba mais</span>
                  <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Seção de Chamada para Ação */}
      <section className="relative bg-gradient-to-r from-gray-900 to-gray-800 py-20 overflow-hidden">
        {/* Sombra de fundo */}
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-0 right-0 w-96 h-96 bg-gray-900 rounded-full mix-blend-multiply filter blur-3xl opacity-40"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Faça Parte da Nossa Comunidade
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Juntos, podemos construir um futuro melhor para Benevente
          </p>
          <Link
            href="/sobre"
            className="inline-flex items-center gap-2 bg-white text-gray-900 px-8 py-4 rounded-lg font-bold hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 shadow-2xl"
          >
            Conheça Nossa Associação
            <ArrowRight size={20} />
          </Link>
        </div>
      </section>
    </div>
  );
}
