'use client';

import { useState, useRef } from "react";
import { Settings, LogOut, Edit2, Plus, Trash2, Save, Image as ImageIcon, X, Lock, FileText, Download } from "lucide-react";
import { useSiteContext } from "@/contexts/SiteContext";

export default function Gestao() {
  const { siteData, updateSiteData, addNoticia, updateNoticia, deleteNoticia, addMembro, updateMembro, deleteMembro, addDespesaCategory, updateDespesaCategory, deleteDespesaCategory, addFonteReceita, updateFonteReceita, deleteFonteReceita, addLancamento, updateLancamento, deleteLancamento, addDocumento, deleteDocumento, addOuvidoriaPedido, updateOuvidoriaPedido, deleteOuvidoriaPedido, saveToLocalStorage } = useSiteContext();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [activeTab, setActiveTab] = useState("home");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [newNoticiaData, setNewNoticiaData] = useState({ titulo: "", conteudo: "", fonte: "", link: "", imagem: undefined as string | undefined });
  const [editingNoticiaId, setEditingNoticiaId] = useState<number | null>(null);
  const [editNoticiaData, setEditNoticiaData] = useState<any>(null);

  const [newMembroData, setNewMembroData] = useState({ nome: "", cargo: "", descricao: "", foto: "" });
  const [editingMembroId, setEditingMembroId] = useState<number | null>(null);
  const [editMembroData, setEditMembroData] = useState<any>(null);

  const [newDespesaData, setNewDespesaData] = useState({ categoria: "", valor: 0, percentual: 0 });
  const [newFonteData, setNewFonteData] = useState({ fonte: "", valor: 0, data: "2025" });

  const [newLancamentoData, setNewLancamentoData] = useState({ data: new Date().toISOString().split('T')[0], tipo: 'receita' as const, descricao: "", categoria: "", valor: 0, observacoes: "" });
  const [newDocumentoData, setNewDocumentoData] = useState({ nome: "", descricao: "", arquivo: "", tipo: "PDF" });
  const fileInputRef2 = useRef<HTMLInputElement>(null);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === "ACBB1996" && password === "12091996") {
      setIsAuthenticated(true);
      setLoginError("");
      setUsername("");
      setPassword("");
    } else {
      setLoginError("Usuário ou senha incorretos");
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, callback: (base64: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        callback(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, callback: (base64: string, tipo: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const tipo = file.type.includes('pdf') ? 'PDF' : file.type.includes('sheet') || file.type.includes('excel') ? 'Excel' : 'Documento';
        callback(reader.result as string, tipo);
      };
      reader.readAsDataURL(file);
    }
  };

  // Notícias
  const handleAddNoticia = () => {
    if (newNoticiaData.titulo.trim() && newNoticiaData.conteudo.trim()) {
      const noticia = {
        id: Math.max(...siteData.noticias.map((n) => n.id), 0) + 1,
        titulo: newNoticiaData.titulo,
        conteudo: newNoticiaData.conteudo,
        data: new Date().toLocaleDateString("pt-BR"),
        imagem: newNoticiaData.imagem,
        fonte: newNoticiaData.fonte || "ACBB",
        link: newNoticiaData.link,
      };
      addNoticia(noticia);
      setNewNoticiaData({ titulo: "", conteudo: "", fonte: "", link: "", imagem: undefined });
      alert("Notícia publicada com sucesso!");
    }
  };

  const handleEditNoticia = (id: number) => {
    const noticia = siteData.noticias.find((n) => n.id === id);
    if (noticia) {
      setEditingNoticiaId(id);
      setEditNoticiaData({ ...noticia });
    }
  };

  const handleSaveNoticia = () => {
    if (editingNoticiaId && editNoticiaData) {
      updateNoticia(editingNoticiaId, editNoticiaData);
      setEditingNoticiaId(null);
      setEditNoticiaData(null);
      alert("Notícia atualizada com sucesso!");
    }
  };

  const handleDeleteNoticia = (id: number) => {
    if (confirm("Tem certeza que deseja deletar esta notícia?")) {
      deleteNoticia(id);
      alert("Notícia deletada com sucesso!");
    }
  };

  // Membros
  const handleAddMembro = () => {
    if (newMembroData.nome.trim() && newMembroData.cargo.trim()) {
      const membro = {
        id: Math.max(...siteData.diretoria.map((m) => m.id), 0) + 1,
        nome: newMembroData.nome,
        cargo: newMembroData.cargo,
        descricao: newMembroData.descricao,
        foto: newMembroData.foto,
      };
      addMembro(membro);
      setNewMembroData({ nome: "", cargo: "", descricao: "", foto: "" });
      alert("Membro adicionado com sucesso!");
    }
  };

  const handleEditMembro = (id: number) => {
    const membro = siteData.diretoria.find((m) => m.id === id);
    if (membro) {
      setEditingMembroId(id);
      setEditMembroData({ ...membro });
    }
  };

  const handleSaveMembro = () => {
    if (editingMembroId && editMembroData) {
      updateMembro(editingMembroId, editMembroData);
      setEditingMembroId(null);
      setEditMembroData(null);
      alert("Membro atualizado com sucesso!");
    }
  };

  const handleDeleteMembro = (id: number) => {
    if (confirm("Tem certeza que deseja deletar este membro?")) {
      deleteMembro(id);
      alert("Membro deletado com sucesso!");
    }
  };

  // Despesas
  const handleAddDespesa = () => {
    if (newDespesaData.categoria.trim()) {
      const despesa = {
        id: Math.max(...siteData.despesasCategories.map((d) => d.id), 0) + 1,
        categoria: newDespesaData.categoria,
        valor: newDespesaData.valor,
        percentual: newDespesaData.percentual,
      };
      addDespesaCategory(despesa);
      setNewDespesaData({ categoria: "", valor: 0, percentual: 0 });
      alert("Categoria de despesa adicionada!");
    }
  };

  const handleDeleteDespesa = (id: number) => {
    if (confirm("Tem certeza que deseja deletar esta categoria?")) {
      deleteDespesaCategory(id);
    }
  };

  // Fontes de Receita
  const handleAddFonte = () => {
    if (newFonteData.fonte.trim()) {
      const fonte = {
        id: Math.max(...siteData.fontesReceita.map((f) => f.id), 0) + 1,
        fonte: newFonteData.fonte,
        valor: newFonteData.valor,
        data: newFonteData.data,
      };
      addFonteReceita(fonte);
      setNewFonteData({ fonte: "", valor: 0, data: "2025" });
      alert("Fonte de receita adicionada!");
    }
  };

  const handleDeleteFonte = (id: number) => {
    if (confirm("Tem certeza que deseja deletar esta fonte?")) {
      deleteFonteReceita(id);
    }
  };

  const handleSaveAll = () => {
    saveToLocalStorage();
    alert("Todas as alterações foram salvas com sucesso!");
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center pt-20">
        <div className="max-w-md w-full mx-4 bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-8 shadow-2xl">
          <div className="flex justify-center mb-6">
            <Lock size={40} className="text-green-500" />
          </div>
          <h1 className="text-3xl font-bold text-white text-center mb-2">Painel de Gestão</h1>
          <p className="text-gray-400 text-center mb-8">Acesso Restrito</p>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-2">Usuário</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                placeholder="Digite seu usuário"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-2">Senha</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                placeholder="••••••••"
              />
            </div>
            {loginError && <p className="text-red-500 text-sm">{loginError}</p>}
            <button
              type="submit"
              className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-2 rounded-lg transition-all duration-300"
            >
              Entrar
            </button>
          </form>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: "home", label: "Home" },
    { id: "sobre", label: "Sobre" },
    { id: "conheca", label: "Conheça Benevente" },
    { id: "mapa", label: "Mapa" },
    { id: "estatuto", label: "Estatuto" },
    { id: "diretoria", label: "Diretoria" },
    { id: "transparencia", label: "Transparência" },
    { id: "ouvidoria", label: "Ouvidoria" },
    { id: "lancamentos", label: "Lançamentos" },
    { id: "documentos", label: "Documentos" },
    { id: "noticias", label: "Notícias" },
  ];

  return (
    <div className="min-h-screen bg-black pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold text-white">Painel de Gestão Completo</h1>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-all"
          >
            <LogOut size={20} />
            Sair
          </button>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap gap-2 mb-8 border-b border-green-900/30 pb-4 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 font-semibold transition-all text-sm whitespace-nowrap ${
                activeTab === tab.id
                  ? "text-green-400 border-b-2 border-green-500"
                  : "text-gray-400 hover:text-gray-300"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* HOME TAB */}
        {activeTab === "home" && (
          <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-6 space-y-6">
            <h2 className="text-2xl font-bold text-white mb-6">Editar Homepage</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Título Hero</label>
                <input
                  type="text"
                  value={siteData.homeHeroTitle}
                  onChange={(e) => updateSiteData({ homeHeroTitle: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Subtítulo Hero</label>
                <input
                  type="text"
                  value={siteData.homeHeroSubtitle}
                  onChange={(e) => updateSiteData({ homeHeroSubtitle: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-300 mb-2">Descrição Hero</label>
                <textarea
                  value={siteData.homeHeroDescription}
                  onChange={(e) => updateSiteData({ homeHeroDescription: e.target.value })}
                  rows={2}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-300 mb-2">Descrição da Seção de Informações</label>
                <textarea
                  value={siteData.homeInfoDescription}
                  onChange={(e) => updateSiteData({ homeInfoDescription: e.target.value })}
                  rows={2}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* SOBRE TAB */}
        {activeTab === "sobre" && (
          <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-6 space-y-6">
            <h2 className="text-2xl font-bold text-white mb-6">Editar Página Sobre</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Título Hero</label>
                <input
                  type="text"
                  value={siteData.sobreHeroTitle}
                  onChange={(e) => updateSiteData({ sobreHeroTitle: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Subtítulo Hero</label>
                <input
                  type="text"
                  value={siteData.sobreHeroSubtitle}
                  onChange={(e) => updateSiteData({ sobreHeroSubtitle: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-300 mb-2">Descrição Hero</label>
                <textarea
                  value={siteData.sobreHeroDescription}
                  onChange={(e) => updateSiteData({ sobreHeroDescription: e.target.value })}
                  rows={2}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-300 mb-2">Conteúdo Fundação</label>
                <textarea
                  value={siteData.sobreFundacaoContent}
                  onChange={(e) => updateSiteData({ sobreFundacaoContent: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-300 mb-2">Missão</label>
                <textarea
                  value={siteData.sobreMissao}
                  onChange={(e) => updateSiteData({ sobreMissao: e.target.value })}
                  rows={2}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-300 mb-2">Visão</label>
                <textarea
                  value={siteData.sobreVisao}
                  onChange={(e) => updateSiteData({ sobreVisao: e.target.value })}
                  rows={2}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-300 mb-2">Valores</label>
                <textarea
                  value={siteData.sobreValores}
                  onChange={(e) => updateSiteData({ sobreValores: e.target.value })}
                  rows={2}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* CONHEÇA BENEVENTE TAB */}
        {activeTab === "conheca" && (
          <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-6 space-y-6">
            <h2 className="text-2xl font-bold text-white mb-6">Editar Conheça Benevente</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Título Hero</label>
                <input
                  type="text"
                  value={siteData.conhecaHeroTitle}
                  onChange={(e) => updateSiteData({ conhecaHeroTitle: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Subtítulo Hero</label>
                <input
                  type="text"
                  value={siteData.conhecaHeroSubtitle}
                  onChange={(e) => updateSiteData({ conhecaHeroSubtitle: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Descrição Hero</label>
                <textarea
                  value={siteData.conhecaHeroDescription}
                  onChange={(e) => updateSiteData({ conhecaHeroDescription: e.target.value })}
                  rows={2}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Conteúdo Completo</label>
                <textarea
                  value={siteData.conhecaContent}
                  onChange={(e) => updateSiteData({ conhecaContent: e.target.value })}
                  rows={8}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* MAPA TAB */}
        {activeTab === "mapa" && (
          <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-6 space-y-6">
            <h2 className="text-2xl font-bold text-white mb-6">Editar Página Mapa</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Título Hero</label>
                <input
                  type="text"
                  value={siteData.mapaHeroTitle}
                  onChange={(e) => updateSiteData({ mapaHeroTitle: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Subtítulo Hero</label>
                <input
                  type="text"
                  value={siteData.mapaHeroSubtitle}
                  onChange={(e) => updateSiteData({ mapaHeroSubtitle: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Conteúdo</label>
                <textarea
                  value={siteData.mapaContent}
                  onChange={(e) => updateSiteData({ mapaContent: e.target.value })}
                  rows={8}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* ESTATUTO TAB */}
        {activeTab === "estatuto" && (
          <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-6 space-y-6">
            <h2 className="text-2xl font-bold text-white mb-6">Editar Estatuto</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Título Hero</label>
                <input
                  type="text"
                  value={siteData.estatutoHeroTitle}
                  onChange={(e) => updateSiteData({ estatutoHeroTitle: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Subtítulo Hero</label>
                <input
                  type="text"
                  value={siteData.estatutoHeroSubtitle}
                  onChange={(e) => updateSiteData({ estatutoHeroSubtitle: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Conteúdo</label>
                <textarea
                  value={siteData.estatutoContent}
                  onChange={(e) => updateSiteData({ estatutoContent: e.target.value })}
                  rows={8}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* DIRETORIA TAB */}
        {activeTab === "diretoria" && (
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-6">
              <h3 className="text-xl font-bold text-white mb-4">Adicionar Novo Membro</h3>
              <div className="space-y-4">
                <input
                  type="text"
                  value={newMembroData.nome}
                  onChange={(e) => setNewMembroData({ ...newMembroData, nome: e.target.value })}
                  placeholder="Nome"
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
                <input
                  type="text"
                  value={newMembroData.cargo}
                  onChange={(e) => setNewMembroData({ ...newMembroData, cargo: e.target.value })}
                  placeholder="Cargo"
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
                <textarea
                  value={newMembroData.descricao}
                  onChange={(e) => setNewMembroData({ ...newMembroData, descricao: e.target.value })}
                  placeholder="Descrição"
                  rows={2}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">Foto do Membro</label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleImageUpload(e, (base64) => setNewMembroData({ ...newMembroData, foto: base64 }))}
                    className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                  />
                </div>
                <button
                  onClick={handleAddMembro}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg transition-all font-semibold"
                >
                  <Plus size={20} />
                  Adicionar Membro
                </button>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-white">Membros da Diretoria ({siteData.diretoria.length})</h3>
              {siteData.diretoria.map((membro) => (
                <div key={membro.id} className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-6">
                  {editingMembroId === membro.id ? (
                    <div className="space-y-4">
                      <input
                        type="text"
                        value={editMembroData.nome}
                        onChange={(e) => setEditMembroData({ ...editMembroData, nome: e.target.value })}
                        className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white"
                      />
                      <input
                        type="text"
                        value={editMembroData.cargo}
                        onChange={(e) => setEditMembroData({ ...editMembroData, cargo: e.target.value })}
                        className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white"
                      />
                      <textarea
                        value={editMembroData.descricao}
                        onChange={(e) => setEditMembroData({ ...editMembroData, descricao: e.target.value })}
                        rows={2}
                        className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white"
                      />
                      <div>
                        <label className="block text-sm font-semibold text-gray-300 mb-2">Foto do Membro</label>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageUpload(e, (base64) => setEditMembroData({ ...editMembroData, foto: base64 }))}
                          className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={handleSaveMembro}
                          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg"
                        >
                          <Save size={20} />
                          Salvar
                        </button>
                        <button
                          onClick={() => setEditingMembroId(null)}
                          className="flex items-center gap-2 bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg"
                        >
                          <X size={20} />
                          Cancelar
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      {membro.foto && (
                        <img src={membro.foto} alt={membro.nome} className="w-24 h-24 rounded-lg object-cover mb-4" />
                      )}
                      <h4 className="text-lg font-bold text-white mb-1">{membro.nome}</h4>
                      <p className="text-green-400 font-semibold mb-2">{membro.cargo}</p>
                      <p className="text-gray-300 mb-4">{membro.descricao}</p>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleEditMembro(membro.id)}
                          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm"
                        >
                          <Edit2 size={16} />
                          Editar
                        </button>
                        <button
                          onClick={() => handleDeleteMembro(membro.id)}
                          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm"
                        >
                          <Trash2 size={16} />
                          Deletar
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TRANSPARÊNCIA TAB */}
        {activeTab === "transparencia" && (
          <div className="space-y-6">
            {/* Dados Financeiros */}
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-6">
              <h2 className="text-2xl font-bold text-white mb-6">Dados Financeiros</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">Receita Total (R$)</label>
                  <input
                    type="number"
                    value={siteData.receitaTotal}
                    onChange={(e) => updateSiteData({ receitaTotal: parseInt(e.target.value) })}
                    className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">Despesas Total (R$)</label>
                  <input
                    type="number"
                    value={siteData.despesasTotal}
                    onChange={(e) => updateSiteData({ despesasTotal: parseInt(e.target.value) })}
                    className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">Saldo (R$)</label>
                  <input
                    type="number"
                    value={siteData.saldo}
                    onChange={(e) => updateSiteData({ saldo: parseInt(e.target.value) })}
                    className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">Ano Financeiro</label>
                  <input
                    type="text"
                    value={siteData.anoFinanceiro}
                    onChange={(e) => updateSiteData({ anoFinanceiro: e.target.value })}
                    className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-semibold text-gray-300 mb-2">Título</label>
                  <input
                    type="text"
                    value={siteData.transparenciaTitulo}
                    onChange={(e) => updateSiteData({ transparenciaTitulo: e.target.value })}
                    className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-semibold text-gray-300 mb-2">Descrição</label>
                  <textarea
                    value={siteData.transparenciaDescricao}
                    onChange={(e) => updateSiteData({ transparenciaDescricao: e.target.value })}
                    rows={2}
                    className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-semibold text-gray-300 mb-2">Conteúdo Completo</label>
                  <textarea
                    value={siteData.transparenciaContent}
                    onChange={(e) => updateSiteData({ transparenciaContent: e.target.value })}
                    rows={4}
                    className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                  />
                </div>
              </div>
            </div>

            {/* Categorias de Despesas */}
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-6">
              <h3 className="text-xl font-bold text-white mb-4">Categorias de Despesas</h3>
              
              <div className="space-y-4 mb-6">
                <input
                  type="text"
                  value={newDespesaData.categoria}
                  onChange={(e) => setNewDespesaData({ ...newDespesaData, categoria: e.target.value })}
                  placeholder="Categoria"
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="number"
                    value={newDespesaData.valor}
                    onChange={(e) => setNewDespesaData({ ...newDespesaData, valor: parseInt(e.target.value) })}
                    placeholder="Valor (R$)"
                    className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                  />
                  <input
                    type="number"
                    value={newDespesaData.percentual}
                    onChange={(e) => setNewDespesaData({ ...newDespesaData, percentual: parseInt(e.target.value) })}
                    placeholder="Percentual (%)"
                    className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                  />
                </div>
                <button
                  onClick={handleAddDespesa}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg transition-all font-semibold"
                >
                  <Plus size={20} />
                  Adicionar Categoria
                </button>
              </div>

              <div className="space-y-3">
                {siteData.despesasCategories.map((despesa) => (
                  <div key={despesa.id} className="bg-gray-800 p-4 rounded-lg flex justify-between items-center">
                    <div className="flex-1">
                      <p className="text-white font-semibold">{despesa.categoria}</p>
                      <p className="text-gray-400 text-sm">R$ {despesa.valor.toLocaleString('pt-BR')} ({despesa.percentual}%)</p>
                    </div>
                    <button
                      onClick={() => handleDeleteDespesa(despesa.id)}
                      className="bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-lg text-sm"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Fontes de Receita */}
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-6">
              <h3 className="text-xl font-bold text-white mb-4">Fontes de Receita</h3>
              
              <div className="space-y-4 mb-6">
                <input
                  type="text"
                  value={newFonteData.fonte}
                  onChange={(e) => setNewFonteData({ ...newFonteData, fonte: e.target.value })}
                  placeholder="Fonte"
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="number"
                    value={newFonteData.valor}
                    onChange={(e) => setNewFonteData({ ...newFonteData, valor: parseInt(e.target.value) })}
                    placeholder="Valor (R$)"
                    className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                  />
                  <input
                    type="text"
                    value={newFonteData.data}
                    onChange={(e) => setNewFonteData({ ...newFonteData, data: e.target.value })}
                    placeholder="Ano"
                    className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                  />
                </div>
                <button
                  onClick={handleAddFonte}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg transition-all font-semibold"
                >
                  <Plus size={20} />
                  Adicionar Fonte
                </button>
              </div>

              <div className="space-y-3">
                {siteData.fontesReceita.map((fonte) => (
                  <div key={fonte.id} className="bg-gray-800 p-4 rounded-lg flex justify-between items-center">
                    <div className="flex-1">
                      <p className="text-white font-semibold">{fonte.fonte}</p>
                      <p className="text-gray-400 text-sm">R$ {fonte.valor.toLocaleString('pt-BR')} - {fonte.data}</p>
                    </div>
                    <button
                      onClick={() => handleDeleteFonte(fonte.id)}
                      className="bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-lg text-sm"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* NOTÍCIAS TAB */}
        {activeTab === "noticias" && (
          <div className="space-y-8">
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-6">
              <h3 className="text-xl font-bold text-white mb-4">Adicionar Nova Notícia</h3>
              <div className="space-y-4">
                <input
                  type="text"
                  value={newNoticiaData.titulo}
                  onChange={(e) => setNewNoticiaData({ ...newNoticiaData, titulo: e.target.value })}
                  placeholder="Título da notícia"
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
                <textarea
                  value={newNoticiaData.conteudo}
                  onChange={(e) => setNewNoticiaData({ ...newNoticiaData, conteudo: e.target.value })}
                  placeholder="Conteúdo da notícia"
                  rows={4}
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
                <input
                  type="text"
                  value={newNoticiaData.fonte}
                  onChange={(e) => setNewNoticiaData({ ...newNoticiaData, fonte: e.target.value })}
                  placeholder="Fonte (ex: MPES, ACBB)"
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
                <input
                  type="text"
                  value={newNoticiaData.link}
                  onChange={(e) => setNewNoticiaData({ ...newNoticiaData, link: e.target.value })}
                  placeholder="Link da notícia original (opcional)"
                  className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
                <div>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={(e) => handleImageUpload(e, (base64) => setNewNoticiaData({ ...newNoticiaData, imagem: base64 }))}
                    accept="image/*"
                    className="hidden"
                  />
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all"
                  >
                    <ImageIcon size={20} />
                    Selecionar Imagem
                  </button>
                  {newNoticiaData.imagem && <p className="text-green-400 text-sm mt-2">Imagem selecionada ✓</p>}
                </div>
                <button
                  onClick={handleAddNoticia}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg transition-all font-semibold"
                >
                  <Plus size={20} />
                  Publicar Notícia
                </button>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-white">Notícias Publicadas ({siteData.noticias.length})</h3>
              {siteData.noticias.map((noticia) => (
                <div key={noticia.id} className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-6">
                  {editingNoticiaId === noticia.id ? (
                    <div className="space-y-4">
                      <input
                        type="text"
                        value={editNoticiaData.titulo}
                        onChange={(e) => setEditNoticiaData({ ...editNoticiaData, titulo: e.target.value })}
                        className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white"
                      />
                      <textarea
                        value={editNoticiaData.conteudo}
                        onChange={(e) => setEditNoticiaData({ ...editNoticiaData, conteudo: e.target.value })}
                        rows={4}
                        className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white"
                      />
                      <input
                        type="text"
                        value={editNoticiaData.fonte}
                        onChange={(e) => setEditNoticiaData({ ...editNoticiaData, fonte: e.target.value })}
                        className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white"
                      />
                      <input
                        type="text"
                        value={editNoticiaData.link}
                        onChange={(e) => setEditNoticiaData({ ...editNoticiaData, link: e.target.value })}
                        className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={handleSaveNoticia}
                          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg"
                        >
                          <Save size={20} />
                          Salvar
                        </button>
                        <button
                          onClick={() => setEditingNoticiaId(null)}
                          className="flex items-center gap-2 bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg"
                        >
                          <X size={20} />
                          Cancelar
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <h4 className="text-lg font-bold text-white mb-2">{noticia.titulo}</h4>
                      <p className="text-gray-400 mb-2 text-sm">{noticia.data} - {noticia.fonte}</p>
                      <p className="text-gray-300 mb-4">{noticia.conteudo.substring(0, 150)}...</p>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleEditNoticia(noticia.id)}
                          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm"
                        >
                          <Edit2 size={16} />
                          Editar
                        </button>
                        <button
                          onClick={() => handleDeleteNoticia(noticia.id)}
                          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm"
                        >
                          <Trash2 size={16} />
                          Deletar
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* LANCAMENTOS TAB */}
        {activeTab === "lancamentos" && (
          <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-6 space-y-6">
            <h2 className="text-2xl font-bold text-white mb-6">Lançamentos Contábeis</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 bg-gray-800 p-4 rounded-lg">
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Data</label>
                <input
                  type="date"
                  value={newLancamentoData.data}
                  onChange={(e) => setNewLancamentoData({ ...newLancamentoData, data: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-700 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Tipo</label>
                <select
                  value={newLancamentoData.tipo}
                  onChange={(e) => setNewLancamentoData({ ...newLancamentoData, tipo: e.target.value as any })}
                  className="w-full px-4 py-2 bg-gray-700 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                >
                  <option value="receita">Receita</option>
                  <option value="despesa">Despesa</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Descrição</label>
                <input
                  type="text"
                  value={newLancamentoData.descricao}
                  onChange={(e) => setNewLancamentoData({ ...newLancamentoData, descricao: e.target.value })}
                  placeholder="Ex: Doação de membro"
                  className="w-full px-4 py-2 bg-gray-700 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Categoria</label>
                <input
                  type="text"
                  value={newLancamentoData.categoria}
                  onChange={(e) => setNewLancamentoData({ ...newLancamentoData, categoria: e.target.value })}
                  placeholder="Ex: Doações"
                  className="w-full px-4 py-2 bg-gray-700 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Valor (R$)</label>
                <input
                  type="number"
                  value={newLancamentoData.valor}
                  onChange={(e) => setNewLancamentoData({ ...newLancamentoData, valor: parseInt(e.target.value) })}
                  placeholder="0"
                  className="w-full px-4 py-2 bg-gray-700 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Observações</label>
                <input
                  type="text"
                  value={newLancamentoData.observacoes}
                  onChange={(e) => setNewLancamentoData({ ...newLancamentoData, observacoes: e.target.value })}
                  placeholder="Opcional"
                  className="w-full px-4 py-2 bg-gray-700 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>
              <div className="md:col-span-2">
                <button
                  onClick={() => {
                    if (newLancamentoData.descricao && newLancamentoData.valor > 0) {
                      addLancamento({ ...newLancamentoData, id: 0 });
                      setNewLancamentoData({ data: new Date().toISOString().split('T')[0], tipo: 'receita' as any, descricao: "", categoria: "", valor: 0, observacoes: "" });
                      alert('Lançamento adicionado com sucesso!');
                    }
                  }}
                  className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg transition-all font-semibold"
                >
                  <Plus size={20} />
                  Adicionar Lançamento
                </button>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="text-xl font-bold text-white mb-4">Histórico de Lançamentos</h3>
              {siteData.lancamentos.length === 0 ? (
                <p className="text-gray-400">Nenhum lançamento registrado</p>
              ) : (
                siteData.lancamentos.map((lancamento) => (
                  <div key={lancamento.id} className="bg-gray-800 p-4 rounded-lg flex justify-between items-center">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className={`px-3 py-1 rounded text-sm font-semibold ${lancamento.tipo === 'receita' ? 'bg-green-900 text-green-300' : 'bg-red-900 text-red-300'}`}>
                          {lancamento.tipo === 'receita' ? '+' : '-'} R$ {lancamento.valor.toLocaleString('pt-BR')}
                        </span>
                        <span className="text-gray-400 text-sm">{lancamento.data}</span>
                      </div>
                      <p className="text-white font-semibold">{lancamento.descricao}</p>
                      <p className="text-gray-400 text-sm">{lancamento.categoria} {lancamento.observacoes && `- ${lancamento.observacoes}`}</p>
                    </div>
                    <button
                      onClick={() => {
                        if (confirm('Tem certeza que deseja deletar este lançamento?')) {
                          deleteLancamento(lancamento.id);
                          alert('Lançamento deletado com sucesso!');
                        }
                      }}
                      className="bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-lg text-sm"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* DOCUMENTOS TAB */}
        {activeTab === "documentos" && (
          <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-6 space-y-6">
            <h2 className="text-2xl font-bold text-white mb-6">Gestão de Documentos</h2>
            
            <div className="bg-gray-800 p-6 rounded-lg space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Nome do Documento</label>
                <input
                  type="text"
                  value={newDocumentoData.nome}
                  onChange={(e) => setNewDocumentoData({ ...newDocumentoData, nome: e.target.value })}
                  placeholder="Ex: Relatório Financeiro 2025"
                  className="w-full px-4 py-2 bg-gray-700 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Descrição</label>
                <textarea
                  value={newDocumentoData.descricao}
                  onChange={(e) => setNewDocumentoData({ ...newDocumentoData, descricao: e.target.value })}
                  placeholder="Descrição do documento"
                  rows={2}
                  className="w-full px-4 py-2 bg-gray-700 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Upload do Arquivo</label>
                <div className="flex gap-2">
                  <input
                    type="file"
                    ref={fileInputRef2}
                    onChange={(e) => handleFileUpload(e, (base64, tipo) => {
                      setNewDocumentoData({ ...newDocumentoData, arquivo: base64, tipo });
                    })}
                    className="hidden"
                    accept=".pdf,.doc,.docx,.xls,.xlsx,.txt"
                  />
                  <button
                    onClick={() => fileInputRef2.current?.click()}
                    className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all"
                  >
                    <FileText size={20} />
                    Selecionar Arquivo
                  </button>
                  {newDocumentoData.arquivo && <span className="text-green-400 text-sm py-2">Arquivo selecionado ({newDocumentoData.tipo})</span>}
                </div>
              </div>
              <button
                onClick={() => {
                  if (newDocumentoData.nome && newDocumentoData.arquivo) {
                    addDocumento({
                      id: 0,
                      nome: newDocumentoData.nome,
                      descricao: newDocumentoData.descricao,
                      arquivo: newDocumentoData.arquivo,
                      tipo: newDocumentoData.tipo,
                      dataUpload: new Date().toLocaleDateString('pt-BR')
                    });
                    setNewDocumentoData({ nome: "", descricao: "", arquivo: "", tipo: "PDF" });
                    alert('Documento adicionado com sucesso!');
                  }
                }}
                className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg transition-all font-semibold"
              >
                <Plus size={20} />
                Adicionar Documento
              </button>
            </div>

            <div className="space-y-3">
              <h3 className="text-xl font-bold text-white mb-4">Documentos Armazenados</h3>
              {siteData.documentos.length === 0 ? (
                <p className="text-gray-400">Nenhum documento armazenado</p>
              ) : (
                siteData.documentos.map((doc) => (
                  <div key={doc.id} className="bg-gray-800 p-4 rounded-lg flex justify-between items-center">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <FileText className="text-blue-400" size={24} />
                        <div>
                          <p className="text-white font-semibold">{doc.nome}</p>
                          <p className="text-gray-400 text-sm">{doc.descricao}</p>
                          <p className="text-gray-500 text-xs">Tipo: {doc.tipo} | Enviado em: {doc.dataUpload}</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <a
                        href={doc.arquivo}
                        download={doc.nome}
                        className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-lg text-sm flex items-center gap-2"
                      >
                        <Download size={16} />
                        Baixar
                      </a>
                      <button
                        onClick={() => {
                          if (confirm('Tem certeza que deseja deletar este documento?')) {
                            deleteDocumento(doc.id);
                            alert('Documento deletado com sucesso!');
                          }
                        }}
                        className="bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-lg text-sm"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* OUVIDORIA TAB */}
        {activeTab === "ouvidoria" && (
          <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl border border-green-900/30 p-6 space-y-6">
            <h2 className="text-2xl font-bold text-white mb-6">Gerenciar Ouvidoria</h2>
            
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-white">Pedidos Recebidos</h3>
              {siteData.ouvidoriaPedidos.length === 0 ? (
                <p className="text-gray-400">Nenhum pedido de ouvidoria recebido</p>
              ) : (
                siteData.ouvidoriaPedidos.map((pedido) => (
                  <div key={pedido.id} className="bg-gray-800 p-6 rounded-lg border border-green-900/20">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <span className="px-3 py-1 rounded text-sm font-semibold bg-blue-900 text-blue-300">
                            {pedido.categoria.toUpperCase()}
                          </span>
                          <span className="text-gray-400 text-sm">Protocolo: {pedido.protocolo}</span>
                        </div>
                        <h4 className="text-white font-bold text-lg">{pedido.assunto}</h4>
                        <p className="text-gray-300 mt-2">{pedido.descricao}</p>
                        <p className="text-gray-500 text-sm mt-2">De: {pedido.nome} ({pedido.email})</p>
                        {pedido.nomeAnexo && (
                          <p className="text-green-400 text-sm mt-2">📎 Anexo: {pedido.nomeAnexo}</p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <select
                          value={pedido.status}
                          onChange={(e) => updateOuvidoriaPedido(pedido.id, { status: e.target.value })}
                          className="px-3 py-2 bg-gray-700 border border-green-900/30 rounded-lg text-white text-sm focus:outline-none focus:border-green-500"
                        >
                          <option value="aberto">Aberto</option>
                          <option value="em_analise">Em Análise</option>
                          <option value="respondido">Respondido</option>
                          <option value="fechado">Fechado</option>
                        </select>
                        <button
                          onClick={() => {
                            if (confirm('Tem certeza que deseja deletar este pedido?')) {
                              deleteOuvidoriaPedido(pedido.id);
                              alert('Pedido deletado com sucesso!');
                            }
                          }}
                          className="bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-lg transition-all"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>

                    {/* Resposta */}
                    <div className="mt-4 p-4 bg-gray-700 rounded-lg">
                      <label className="block text-sm font-semibold text-gray-300 mb-2">Resposta</label>
                      <textarea
                        value={pedido.resposta || ''}
                        onChange={(e) => updateOuvidoriaPedido(pedido.id, { resposta: e.target.value, dataResposta: new Date().toISOString().split('T')[0] })}
                        rows={3}
                        placeholder="Digite a resposta ao pedido..."
                        className="w-full px-4 py-2 bg-gray-800 border border-green-900/30 rounded-lg text-white focus:outline-none focus:border-green-500"
                      />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Salvar Dados */}
        <div className="mt-8 flex justify-end">
          <button
            onClick={handleSaveAll}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-lg transition-all font-semibold text-lg"
          >
            <Save size={24} />
            Salvar Todas as Mudanças
          </button>
        </div>
      </div>
    </div>
  );
}
