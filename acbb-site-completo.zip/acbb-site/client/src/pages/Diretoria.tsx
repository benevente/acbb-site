import { Award } from "lucide-react";
import { useSiteContext } from "@/contexts/SiteContext";

export default function Diretoria() {
  const { siteData } = useSiteContext();
  const membros = siteData.diretoria;

  return (
    <div className="min-h-screen bg-black pt-20">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-gray-900 to-black py-20">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-0 w-96 h-96 bg-green-900 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-green-800 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Diretoria da ACBB
          </h1>
          <p className="text-xl text-green-300 mb-4">
            Conheça Nossos Líderes
          </p>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Membros dedicados que trabalham pelo desenvolvimento e preservação de Benevente
          </p>
        </div>
      </section>

      {/* Membros da Diretoria */}
      <section className="relative bg-black py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
            {membros.map((membro: any) => (
              <div
                key={membro.id}
                className="group relative bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl overflow-hidden border border-green-900/30 hover:border-green-600/60 transition-all duration-300 transform hover:scale-105 shadow-2xl hover:shadow-green-900/50"
              >
                {/* Sombra sofisticada por trás */}
                <div className="absolute inset-0 bg-gradient-to-br from-green-600/20 to-green-900/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl -z-10"></div>

                <div className="relative aspect-square overflow-hidden bg-gray-700 flex items-center justify-center">
                  {membro.foto ? (
                    <img
                      src={membro.foto}
                      alt={membro.nome}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  ) : (
                    <Award size={48} className="text-gray-400" />
                  )}
                </div>

                <div className="p-6 relative z-10">
                  <h3 className="text-xl font-bold text-white mb-1 group-hover:text-green-400 transition-colors">
                    {membro.nome}
                  </h3>
                  <p className="text-green-500 font-semibold mb-4 flex items-center gap-2">
                    <Award size={16} />
                    {membro.cargo}
                  </p>
                  <p className="text-gray-400 text-sm leading-relaxed group-hover:text-gray-300 transition-colors">
                    {membro.descricao}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Sobre a Gestão */}
          <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 border border-green-900/30 rounded-xl p-12">
            <h2 className="text-4xl font-bold text-white mb-8">Sobre a Gestão</h2>
            <div className="space-y-6">
              <p className="text-gray-300 leading-relaxed">
                A diretoria da ACBB é composta por membros dedicados que trabalham voluntariamente pelo bem-estar e desenvolvimento da comunidade de Benevente. Cada membro traz experiência, compromisso e paixão pelos objetivos da associação.
              </p>
              <p className="text-gray-300 leading-relaxed">
                A gestão é pautada pelos princípios de transparência, responsabilidade e inclusão, buscando sempre ouvir e envolver a comunidade nas decisões importantes da associação. Acreditamos que o sucesso de nossos projetos depende do engajamento coletivo.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
                <div className="bg-gray-900/50 p-6 rounded-lg border border-green-900/20">
                  <h3 className="font-bold text-green-400 mb-3">Transparência</h3>
                  <p className="text-gray-400 text-sm">
                    Todas as decisões e contas são públicas e acessíveis à comunidade
                  </p>
                </div>
                <div className="bg-gray-900/50 p-6 rounded-lg border border-green-900/20">
                  <h3 className="font-bold text-green-400 mb-3">Responsabilidade</h3>
                  <p className="text-gray-400 text-sm">
                    Cada membro assume compromissos claros com a comunidade
                  </p>
                </div>
                <div className="bg-gray-900/50 p-6 rounded-lg border border-green-900/20">
                  <h3 className="font-bold text-green-400 mb-3">Inclusão</h3>
                  <p className="text-gray-400 text-sm">
                    Valorizamos a participação de todos os membros da comunidade
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
