import { Link } from "wouter";
import { Calendar, MapPin, ExternalLink, Newspaper, TrendingUp, Clock } from "lucide-react";
import { useSiteContext } from "@/contexts/SiteContext";
import { useState, useEffect } from "react";

// Componente de Previsão do Tempo
function WeatherWidget() {
  const [weather, setWeather] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Usando Open-Meteo API (gratuita, sem necessidade de chave)
    // Coordenadas de Anchieta, ES: -20.8, -40.65
    fetch('https://api.open-meteo.com/v1/forecast?latitude=-20.8&longitude=-40.65&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&timezone=America/Sao_Paulo')
      .then(res => res.json())
      .then(data => {
        setWeather(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Erro ao buscar clima:', err);
        setLoading(false);
      });
  }, []);

  const getWeatherDescription = (code: number) => {
    if (code === 0) return "Céu limpo";
    if (code <= 3) return "Parcialmente nublado";
    if (code <= 48) return "Nublado";
    if (code <= 67) return "Chuva";
    if (code <= 77) return "Neve";
    if (code <= 99) return "Tempestade";
    return "Variável";
  };

  if (loading) {
    return (
      <div className="bg-gradient-to-br from-blue-900 to-blue-800 rounded-lg p-6 text-white">
        <div className="animate-pulse">
          <div className="h-4 bg-blue-700 rounded w-3/4 mb-2"></div>
          <div className="h-8 bg-blue-700 rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  if (!weather || !weather.current) {
    return null;
  }

  return (
    <div className="bg-gradient-to-br from-blue-900 to-blue-800 rounded-lg p-6 text-white shadow-xl border border-blue-700">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="text-sm font-semibold text-blue-200 mb-1">Anchieta, ES</h3>
          <div className="flex items-baseline gap-2">
            <span className="text-5xl font-bold">{Math.round(weather.current.temperature_2m)}°</span>
            <span className="text-xl text-blue-200">C</span>
          </div>
          <p className="text-blue-200 mt-2">{getWeatherDescription(weather.current.weather_code)}</p>
        </div>
        <div className="text-right">
          <div className="text-sm text-blue-200">
            <div className="mb-1">💧 {weather.current.relative_humidity_2m}%</div>
            <div>💨 {Math.round(weather.current.wind_speed_10m)} km/h</div>
          </div>
        </div>
      </div>
      <div className="mt-4 pt-4 border-t border-blue-700">
        <p className="text-xs text-blue-300">Atualizado agora</p>
      </div>
    </div>
  );
}

export default function Noticias() {
  const { siteData } = useSiteContext();
  const noticias = siteData.noticias;

  // Ordenar notícias por data (mais recente primeiro)
  const noticiasSorted = [...noticias].sort((a, b) => {
    const dateA = new Date(a.data).getTime();
    const dateB = new Date(b.data).getTime();
    return dateB - dateA;
  });

  // Notícia principal (mais recente)
  const noticiaDestaque = noticiasSorted[0];
  // Notícias secundárias
  const noticiasSecundarias = noticiasSorted.slice(1, 4);
  // Demais notícias
  const noticiasRestantes = noticiasSorted.slice(4);

  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      {/* Cabeçalho estilo jornal */}
      <section className="bg-white border-b-4 border-black py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center border-b-2 border-gray-300 pb-6 mb-6">
            <div className="flex items-center justify-center gap-3 mb-2">
              <Newspaper className="w-8 h-8 text-green-700" />
              <h1 className="text-5xl md:text-6xl font-bold text-gray-900" style={{ fontFamily: 'Georgia, serif' }}>
                Notícias ACBB
              </h1>
            </div>
            <p className="text-sm text-gray-600 uppercase tracking-wider">
              Benevente • Anchieta • Espírito Santo
            </p>
          </div>
          <div className="flex items-center justify-between text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span>{new Date().toLocaleDateString('pt-BR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
            </div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <span className="font-semibold text-green-700">{noticias.length} notícias publicadas</span>
            </div>
          </div>
        </div>
      </section>

      {/* Grid Principal de Notícias */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {noticias.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-lg shadow-sm">
            <Newspaper className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-lg">Nenhuma notícia publicada ainda.</p>
            <p className="text-gray-400 text-sm mt-2">Volte em breve para conferir as novidades!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Coluna Principal - Notícia Destaque + Secundárias */}
            <div className="lg:col-span-2 space-y-8">
              {/* Notícia Destaque */}
              {noticiaDestaque && (
                <article className="bg-white rounded-lg shadow-lg overflow-hidden border border-gray-200 hover:shadow-xl transition-shadow">
                  {noticiaDestaque.imagem && (
                    <div className="relative h-96 overflow-hidden">
                      <img
                        src={noticiaDestaque.imagem}
                        alt={noticiaDestaque.titulo}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute top-4 left-4">
                        <span className="bg-red-600 text-white px-3 py-1 text-xs font-bold uppercase tracking-wider">
                          Destaque
                        </span>
                      </div>
                    </div>
                  )}
                  <div className="p-8">
                    <div className="flex flex-wrap gap-4 mb-4 text-sm text-gray-500">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-green-600" />
                        <span>{noticiaDestaque.data}</span>
                      </div>
                      {noticiaDestaque.fonte && (
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-green-600" />
                          <span className="text-green-700 font-semibold">{noticiaDestaque.fonte}</span>
                        </div>
                      )}
                    </div>
                    <h2 className="text-4xl font-bold text-gray-900 mb-4 leading-tight" style={{ fontFamily: 'Georgia, serif' }}>
                      {noticiaDestaque.titulo}
                    </h2>
                    <p className="text-gray-700 text-lg leading-relaxed mb-6">
                      {noticiaDestaque.conteudo}
                    </p>
                    {noticiaDestaque.link && (
                      <a
                        href={noticiaDestaque.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 px-6 py-3 bg-green-700 hover:bg-green-800 text-white font-semibold rounded transition-colors"
                      >
                        Ler Notícia Completa
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    )}
                  </div>
                </article>
              )}

              {/* Notícias Secundárias em Grade */}
              {noticiasSecundarias.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {noticiasSecundarias.map((noticia) => (
                    <article
                      key={noticia.id}
                      className="bg-white rounded-lg shadow overflow-hidden border border-gray-200 hover:shadow-lg transition-shadow"
                    >
                      {noticia.imagem && (
                        <div className="relative h-48 overflow-hidden">
                          <img
                            src={noticia.imagem}
                            alt={noticia.titulo}
                            className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                          />
                        </div>
                      )}
                      <div className="p-6">
                        <div className="flex items-center gap-2 mb-3 text-xs text-gray-500">
                          <Clock className="w-3 h-3" />
                          <span>{noticia.data}</span>
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-3 leading-tight" style={{ fontFamily: 'Georgia, serif' }}>
                          {noticia.titulo}
                        </h3>
                        <p className="text-gray-600 text-sm leading-relaxed mb-4 line-clamp-3">
                          {noticia.conteudo}
                        </p>
                        {noticia.link && (
                          <a
                            href={noticia.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-2 text-green-700 hover:text-green-800 font-semibold text-sm transition-colors"
                          >
                            Leia mais
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
                      </div>
                    </article>
                  ))}
                </div>
              )}

              {/* Demais Notícias - Lista Compacta */}
              {noticiasRestantes.length > 0 && (
                <div className="bg-white rounded-lg shadow border border-gray-200 p-6">
                  <h3 className="text-2xl font-bold text-gray-900 mb-6 pb-3 border-b-2 border-gray-200" style={{ fontFamily: 'Georgia, serif' }}>
                    Mais Notícias
                  </h3>
                  <div className="space-y-6">
                    {noticiasRestantes.map((noticia) => (
                      <article key={noticia.id} className="border-b border-gray-100 pb-6 last:border-0 last:pb-0">
                        <div className="flex gap-4">
                          {noticia.imagem && (
                            <div className="flex-shrink-0 w-32 h-24 overflow-hidden rounded">
                              <img
                                src={noticia.imagem}
                                alt={noticia.titulo}
                                className="w-full h-full object-cover"
                              />
                            </div>
                          )}
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2 text-xs text-gray-500">
                              <Calendar className="w-3 h-3" />
                              <span>{noticia.data}</span>
                            </div>
                            <h4 className="text-lg font-bold text-gray-900 mb-2 leading-tight" style={{ fontFamily: 'Georgia, serif' }}>
                              {noticia.titulo}
                            </h4>
                            <p className="text-gray-600 text-sm line-clamp-2 mb-2">
                              {noticia.conteudo}
                            </p>
                            {noticia.link && (
                              <a
                                href={noticia.link}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 text-green-700 hover:text-green-800 font-semibold text-xs transition-colors"
                              >
                                Leia mais
                                <ExternalLink className="w-3 h-3" />
                              </a>
                            )}
                          </div>
                        </div>
                      </article>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar - Previsão do Tempo e Informações */}
            <div className="lg:col-span-1 space-y-6">
              {/* Previsão do Tempo */}
              <WeatherWidget />

              {/* Sobre a ACBB */}
              <div className="bg-white rounded-lg shadow border border-gray-200 p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4 pb-3 border-b-2 border-gray-200" style={{ fontFamily: 'Georgia, serif' }}>
                  Sobre a ACBB
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed mb-4">
                  A Associação Comunitária do Bairro Benevente trabalha pela preservação cultural e desenvolvimento sustentável da nossa comunidade.
                </p>
                <Link href="/sobre">
                  <a className="text-green-700 hover:text-green-800 font-semibold text-sm transition-colors">
                    Saiba mais →
                  </a>
                </Link>
              </div>

              {/* Contato */}
              <div className="bg-gradient-to-br from-green-700 to-green-800 rounded-lg shadow-lg p-6 text-white">
                <h3 className="text-xl font-bold mb-4" style={{ fontFamily: 'Georgia, serif' }}>
                  Fale Conosco
                </h3>
                <div className="space-y-3 text-sm">
                  <p>📧 contato.acbb@outlook.com.br</p>
                  <p>📱 (27) 99693-8845</p>
                  <p>📍 Benevente, Anchieta-ES</p>
                </div>
                <Link href="/ouvidoria">
                  <a className="mt-4 block w-full text-center px-4 py-2 bg-white text-green-700 font-semibold rounded hover:bg-gray-100 transition-colors">
                    Enviar Mensagem
                  </a>
                </Link>
              </div>

              {/* Acesso à Gestão */}
              <div className="bg-gray-100 rounded-lg border border-gray-300 p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-3" style={{ fontFamily: 'Georgia, serif' }}>
                  Administrador?
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  Acesse o painel para gerenciar notícias e conteúdo.
                </p>
                <Link href="/gestao">
                  <a className="block w-full text-center px-4 py-2 bg-green-700 hover:bg-green-800 text-white font-semibold rounded transition-colors">
                    Painel de Gestão
                  </a>
                </Link>
              </div>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
