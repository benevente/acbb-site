import { useState } from 'react';
import { MessageSquare, ThumbsDown, Lightbulb, AlertTriangle, Info, ThumbsUp, Send, FileUp, X, TrendingUp, Clock, CheckCircle } from 'lucide-react';
import { useSiteContext } from '@/contexts/SiteContext';
import emailjs from '@emailjs/browser';
import { nanoid } from 'nanoid';

interface OuvidoriaPedido {
  id: number;
  protocolo: string;
  categoria: string;
  nome: string;
  email: string;
  telefone: string;
  assunto: string;
  descricao: string;
  anexo?: string;
  nomeAnexo?: string;
  data: string;
  status: string;
  resposta?: string;
  dataResposta?: string;
}

// Componente de Estatísticas
function EstatisticasOuvidoria({ pedidos }: { pedidos: OuvidoriaPedido[] }) {
  const totalPedidos = pedidos.length;
  const pedidosResolvidos = pedidos.filter(p => p.status === 'respondido').length;
  const pedidosAbertos = pedidos.filter(p => p.status === 'aberto').length;
  
  const calcularTempoMedioResposta = () => {
    const pedidosComResposta = pedidos.filter(p => p.dataResposta && p.data);
    if (pedidosComResposta.length === 0) return 0;
    
    const tempos = pedidosComResposta.map(p => {
      const dataPedido = new Date(p.data);
      const dataResposta = new Date(p.dataResposta || '');
      return (dataResposta.getTime() - dataPedido.getTime()) / (1000 * 60 * 60 * 24); // em dias
    });
    
    const mediaTempos = tempos.reduce((a, b) => a + b, 0) / tempos.length;
    return Math.round(mediaTempos);
  };

  const tempoMedioResposta = calcularTempoMedioResposta();

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
      {/* Total de Pedidos */}
      <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg shadow-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-blue-100 text-sm font-semibold mb-1">Total de Pedidos</p>
            <p className="text-4xl font-bold">{totalPedidos}</p>
          </div>
          <TrendingUp className="w-12 h-12 opacity-30" />
        </div>
      </div>

      {/* Pedidos Resolvidos */}
      <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-lg shadow-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-green-100 text-sm font-semibold mb-1">Resolvidos</p>
            <p className="text-4xl font-bold">{pedidosResolvidos}</p>
            <p className="text-green-100 text-xs mt-1">
              {totalPedidos > 0 ? Math.round((pedidosResolvidos / totalPedidos) * 100) : 0}% de resolução
            </p>
          </div>
          <CheckCircle className="w-12 h-12 opacity-30" />
        </div>
      </div>

      {/* Pedidos Abertos */}
      <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg shadow-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-orange-100 text-sm font-semibold mb-1">Em Aberto</p>
            <p className="text-4xl font-bold">{pedidosAbertos}</p>
            <p className="text-orange-100 text-xs mt-1">Aguardando resposta</p>
          </div>
          <Clock className="w-12 h-12 opacity-30" />
        </div>
      </div>

      {/* Tempo Médio de Resposta */}
      <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg shadow-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-purple-100 text-sm font-semibold mb-1">Tempo Médio</p>
            <p className="text-4xl font-bold">{tempoMedioResposta}</p>
            <p className="text-purple-100 text-xs mt-1">dias para responder</p>
          </div>
          <Clock className="w-12 h-12 opacity-30" />
        </div>
      </div>
    </div>
  );
}

export default function Ouvidoria() {
  const { siteData, addOuvidoriaPedido } = useSiteContext();
  const [selectedCategory, setSelectedCategory] = useState<string>('sugestao');
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefone: '',
    assunto: '',
    descricao: '',
    anexo: '',
    nomeAnexo: '',
  });
  const [showForm, setShowForm] = useState(false);
  const [showSucesso, setShowSucesso] = useState(false);
  const [showConsulta, setShowConsulta] = useState(false);
  const [protocoloConsulta, setProtocoloConsulta] = useState('');
  const [resultadoConsulta, setResultadoConsulta] = useState<OuvidoriaPedido | null>(null);
  const [consultaInvalida, setConsultaInvalida] = useState(false);
  const [protocolo, setProtocolo] = useState('');
  const [isSending, setIsSending] = useState(false);

  const categories = [
    { id: 'sugestao', label: 'SUGESTÃO', icon: MessageSquare, color: 'bg-green-600', desc: 'Compartilhe suas ideias' },
    { id: 'reclamacao', label: 'RECLAMAÇÃO', icon: ThumbsDown, color: 'bg-orange-600', desc: 'Informe problemas' },
    { id: 'solicitacao', label: 'SOLICITAÇÃO', icon: Lightbulb, color: 'bg-red-600', desc: 'Solicite serviços' },
    { id: 'denuncia', label: 'DENÚNCIA', icon: AlertTriangle, color: 'bg-blue-600', desc: 'Denuncie irregularidades' },
    { id: 'informacao', label: 'INFORMAÇÃO', icon: Info, color: 'bg-purple-600', desc: 'Solicite informações' },
    { id: 'elogio', label: 'ELOGIO', icon: ThumbsUp, color: 'bg-yellow-600', desc: 'Elogie iniciativas' },
  ];

  const generateProtocol = () => {
    const date = new Date();
    const year = date.getFullYear().toString().slice(2);
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const uniqueId = nanoid(6).toUpperCase();
    return `ACBB-${year}${month}${day}-${uniqueId}`;
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        setFormData({
          ...formData,
          anexo: base64,
          nomeAnexo: file.name,
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSending(true);

    if (!formData.nome || !formData.email || !formData.assunto || !formData.descricao) {
      alert('Por favor, preencha todos os campos obrigatórios');
      setIsSending(false);
      return;
    }

    const newProtocolo = generateProtocol();
    const newPedido: OuvidoriaPedido = {
      id: siteData.ouvidoriaPedidos.length + 1,
      protocolo: newProtocolo,
      categoria: selectedCategory,
      nome: formData.nome,
      email: formData.email,
      telefone: formData.telefone,
      assunto: formData.assunto,
      descricao: formData.descricao,
      anexo: formData.anexo,
      nomeAnexo: formData.nomeAnexo,
      data: new Date().toLocaleDateString('pt-BR'),
      status: 'Recebido',
    };

    const templateParams = {
      protocolo: newProtocolo,
      categoria: categories.find(c => c.id === selectedCategory)?.label || selectedCategory,
      nome: formData.nome,
      email: formData.email,
      telefone: formData.telefone,
      assunto: formData.assunto,
      descricao: formData.descricao,
      data: newPedido.data,
      email_associacao: siteData.email,
      reply_to: formData.email,
      logo_url: '/logo-acbb.png',
    };

    try {
      // Enviar e-mail de confirmação para o usuário
      await emailjs.send(
        'service_acbb_ouvidoria', // Substituir pelo ID do Serviço EmailJS
        'template_user_confirmation', // Substituir pelo ID do Template
        templateParams,
        'PUBLIC_KEY_EMAILJS' // Substituir pela Chave Pública EmailJS
      );

      // Enviar e-mail de notificação para a associação
      await emailjs.send(
        'service_acbb_ouvidoria',
        'template_association_notification',
        templateParams,
        'PUBLIC_KEY_EMAILJS'
      );

      // Salvar o pedido
      addOuvidoriaPedido(newPedido);
      setProtocolo(newProtocolo);
      setShowForm(false);
      setShowSucesso(true);
      
      setTimeout(() => {
        setShowSucesso(false);
      }, 5000);
      
    } catch (error) {
      console.error('Erro ao enviar e-mail:', error);
      // Mesmo com erro no e-mail, salvar o pedido localmente
      addOuvidoriaPedido(newPedido);
      setProtocolo(newProtocolo);
      setShowForm(false);
      setShowSucesso(true);
    } finally {
      setIsSending(false);
      setFormData({
        nome: '',
        email: '',
        telefone: '',
        assunto: '',
        descricao: '',
        anexo: '',
        nomeAnexo: '',
      });
    }
  };

  const handleConsulta = () => {
    const resultado = siteData.ouvidoriaPedidos.find(p => p.protocolo === protocoloConsulta);
    if (resultado) {
      setResultadoConsulta(resultado);
      setConsultaInvalida(false);
    } else {
      setResultadoConsulta(null);
      setConsultaInvalida(true);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-green-700 to-green-800 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">Ouvidoria ACBB</h1>
          <p className="text-xl text-green-100">
            Sua voz importa. Compartilhe suas sugestões, reclamações e elogios conosco.
          </p>
        </div>
      </section>

      {/* Conteúdo Principal */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Estatísticas */}
        <EstatisticasOuvidoria pedidos={siteData.ouvidoriaPedidos} />

        {/* Mensagem de Sucesso */}
        {showSucesso && (
          <div className="mb-8 p-6 bg-green-50 border-l-4 border-green-600 rounded-lg">
            <div className="flex items-start">
              <CheckCircle className="w-6 h-6 text-green-600 mr-4 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="text-lg font-bold text-green-800 mb-2">Pedido Recebido com Sucesso!</h3>
                <p className="text-green-700 mb-2">
                  Seu pedido foi registrado e você receberá um e-mail de confirmação em breve.
                </p>
                <p className="text-green-700 font-semibold">
                  Número de Protocolo: <span className="text-lg">{protocolo}</span>
                </p>
                <p className="text-green-600 text-sm mt-2">
                  Guarde este número para consultar o status do seu pedido.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Grid Principal */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Coluna Principal */}
          <div className="lg:col-span-2 space-y-8">
            {/* Categorias */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Escolha o Tipo de Pedido</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {categories.map((cat) => {
                  const IconComponent = cat.icon;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        selectedCategory === cat.id
                          ? `${cat.color} text-white border-transparent`
                          : 'bg-gray-50 text-gray-700 border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <IconComponent className="w-6 h-6 mx-auto mb-2" />
                      <p className="text-sm font-semibold">{cat.label}</p>
                      <p className="text-xs mt-1 opacity-75">{cat.desc}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Formulário */}
            {showForm ? (
              <div className="bg-white rounded-lg shadow-lg p-8">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-gray-900">Preencha o Formulário</h2>
                  <button
                    onClick={() => setShowForm(false)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <X size={24} />
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Nome */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Nome Completo *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.nome}
                      onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
                      placeholder="Seu nome completo"
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      E-mail *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
                      placeholder="seu.email@exemplo.com"
                    />
                  </div>

                  {/* Telefone */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Telefone
                    </label>
                    <input
                      type="tel"
                      value={formData.telefone}
                      onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
                      placeholder="(27) 99999-9999"
                    />
                  </div>

                  {/* Assunto */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Assunto *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.assunto}
                      onChange={(e) => setFormData({ ...formData, assunto: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
                      placeholder="Título do seu pedido"
                    />
                  </div>

                  {/* Descrição */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Descrição Detalhada *
                    </label>
                    <textarea
                      required
                      value={formData.descricao}
                      onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600 h-32"
                      placeholder="Descreva seu pedido em detalhes..."
                    />
                  </div>

                  {/* Upload de Arquivo */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Anexar Arquivo (Opcional)
                    </label>
                    <div className="flex items-center gap-4">
                      <label className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg cursor-pointer transition-colors">
                        <FileUp size={18} />
                        <span className="text-sm font-semibold">Escolher arquivo</span>
                        <input
                          type="file"
                          onChange={handleFileUpload}
                          className="hidden"
                          accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                        />
                      </label>
                      {formData.nomeAnexo && (
                        <span className="text-sm text-green-600 font-semibold">
                          ✓ {formData.nomeAnexo}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Botão Enviar */}
                  <button
                    type="submit"
                    disabled={isSending}
                    className={`w-full flex items-center justify-center gap-2 px-6 py-3 text-white font-semibold rounded-lg transition-all duration-300 ${
                      isSending
                        ? 'bg-gray-500 cursor-not-allowed'
                        : 'bg-green-600 hover:bg-green-700 hover:scale-105'
                    }`}
                  >
                    {isSending ? (
                      <>
                        <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Enviando...
                      </>
                    ) : (
                      <>
                        <Send size={20} />
                        Enviar Pedido
                      </>
                    )}
                  </button>
                </form>
              </div>
            ) : (
              <button
                onClick={() => setShowForm(true)}
                className="w-full px-6 py-4 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-all duration-300 transform hover:scale-105 text-lg"
              >
                Criar Novo Pedido
              </button>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Consultar Protocolo */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Consultar Protocolo</h3>
              <div className="space-y-3">
                <input
                  type="text"
                  value={protocoloConsulta}
                  onChange={(e) => setProtocoloConsulta(e.target.value.toUpperCase())}
                  placeholder="Ex: ACBB-251110-ABC123"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
                />
                <button
                  onClick={handleConsulta}
                  className="w-full px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-colors"
                >
                  Consultar
                </button>
              </div>

              {consultaInvalida && (
                <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-700 text-sm">Protocolo não encontrado.</p>
                </div>
              )}

              {resultadoConsulta && (
                <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-sm text-gray-600 mb-2">
                    <strong>Protocolo:</strong> {resultadoConsulta.protocolo}
                  </p>
                  <p className="text-sm text-gray-600 mb-2">
                    <strong>Status:</strong> <span className="text-green-700 font-semibold">{resultadoConsulta.status}</span>
                  </p>
                  <p className="text-sm text-gray-600 mb-2">
                    <strong>Data:</strong> {resultadoConsulta.data}
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Categoria:</strong> {resultadoConsulta.categoria}
                  </p>
                </div>
              )}
            </div>

            {/* Informações */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Informações Úteis</h3>
              <div className="space-y-3 text-sm text-gray-600">
                <p>
                  <strong>Tempo de Resposta:</strong> Respondemos em até 7 dias úteis.
                </p>
                <p>
                  <strong>Protocolo:</strong> Guarde seu número de protocolo para acompanhar.
                </p>
                <p>
                  <strong>Confidencialidade:</strong> Seus dados são tratados com sigilo.
                </p>
                <p>
                  <strong>Contato:</strong> {siteData.email}
                </p>
              </div>
            </div>

            {/* Logo ACBB */}
            <div className="bg-white rounded-lg shadow-lg p-6 text-center">
              <img src="/logo-acbb.png" alt="Logo ACBB" className="w-full h-auto" />
              <p className="text-xs text-gray-600 mt-4">
                Associação Comunitária do Bairro Benevente
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
