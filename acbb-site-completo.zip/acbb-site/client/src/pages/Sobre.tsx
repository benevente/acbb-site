import { BookOpen, Award, Users, Leaf, Heart, Target } from "lucide-react";
import { useSiteContext } from "@/contexts/SiteContext";

export default function Sobre() {
  const { siteData } = useSiteContext();
  return (
    <div className="min-h-screen bg-black pt-20">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-gray-900 to-black py-20">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-0 w-96 h-96 bg-green-900 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-green-800 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            {siteData.sobreHeroTitle}
          </h1>
          <p className="text-xl text-green-300 mb-4">
            {siteData.sobreHeroSubtitle}
          </p>
          <p className="text-gray-300 max-w-2xl mx-auto">
            {siteData.sobreHeroDescription}
          </p>
        </div>
      </section>

      {/* Conteúdo Principal */}
      <section className="relative bg-black py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Fundação */}
          <div className="mb-20">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl font-bold text-white mb-6 flex items-center gap-3">
                  <BookOpen className="text-green-500" size={40} />
                  Fundação da ACBB
                </h2>
                <p className="text-gray-300 leading-relaxed mb-4">
                  {siteData.sobreFundacaoContent}
                </p>
              </div>
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-green-600/20 to-green-900/20 rounded-xl blur-2xl"></div>
                <img
                  src="/mapa-benevente.png"
                  alt="Mapa do Bairro Benevente"
                  className="relative rounded-xl shadow-2xl hover:shadow-green-900/50 transition-shadow duration-300"
                />
              </div>
            </div>
          </div>

          {/* Missão, Visão e Valores */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold text-white mb-12 text-center">Missão, Visão e Valores</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="group relative bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-xl border border-green-900/30 hover:border-green-600/60 transition-all duration-300 transform hover:scale-105">
                <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-green-900/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl -z-10"></div>
                <Target className="text-green-500 mb-4" size={40} />
                <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-green-400 transition-colors">
                  Missão
                </h3>
                <p className="text-gray-400 group-hover:text-gray-300 transition-colors">
                  {siteData.sobreMissao}
                </p>
              </div>

              <div className="group relative bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-xl border border-green-900/30 hover:border-green-600/60 transition-all duration-300 transform hover:scale-105">
                <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-green-900/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl -z-10"></div>
                <Leaf className="text-green-500 mb-4" size={40} />
                <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-green-400 transition-colors">
                  Visão
                </h3>
                <p className="text-gray-400 group-hover:text-gray-300 transition-colors">
                  {siteData.sobreVisao}
                </p>
              </div>

              <div className="group relative bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-xl border border-green-900/30 hover:border-green-600/60 transition-all duration-300 transform hover:scale-105">
                <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-green-900/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl -z-10"></div>
                <Heart className="text-green-500 mb-4" size={40} />
                <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-green-400 transition-colors">
                  Valores
                </h3>
                <p className="text-gray-400 group-hover:text-gray-300 transition-colors">
                  {siteData.sobreValores}
                </p>
              </div>
            </div>
          </div>

          {/* Realizações */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold text-white mb-12 text-center">Principais Realizações</h2>
            <div className="space-y-8">
              {[
                {
                  icon: Award,
                  title: "Reconhecimento de Utilidade Pública",
                  desc: "Em 2025, a ACBB foi reconhecida como Utilidade Pública pela Lei Estadual nº 12.605/2025, consolidando seu papel na defesa dos interesses comunitários.",
                },
                {
                  icon: Users,
                  title: "Mobilização e Participação Comunitária",
                  desc: "Organização de eventos, assembleias e atividades que promovem o engajamento dos moradores na vida comunitária e nas decisões que afetam o bairro.",
                },
                {
                  icon: Leaf,
                  title: "Desenvolvimento Sustentável",
                  desc: "Iniciativas de preservação ambiental, limpeza comunitária e educação ecológica para um futuro mais sustentável.",
                },
                {
                  icon: BookOpen,
                  title: "Promoção da Cultura Local",
                  desc: "Valorização das tradições, memória coletiva e expressões culturais que definem a identidade única de Benevente.",
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="group relative bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-xl border border-green-900/30 hover:border-green-600/60 transition-all duration-300"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-green-900/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl -z-10"></div>

                  <div className="flex gap-6">
                    <item.icon className="text-green-500 flex-shrink-0" size={40} />
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-green-400 transition-colors">
                        {item.title}
                      </h3>
                      <p className="text-gray-400 group-hover:text-gray-300 transition-colors leading-relaxed">
                        {item.desc}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* O Que Defendemos */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold text-white mb-12 text-center">O Que Defendemos</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                {
                  title: "Cultura e Identidade",
                  desc: "Preservação e valorização das tradições, expressões culturais e memória coletiva que definem Benevente",
                },
                {
                  title: "Boa Convivência",
                  desc: "Promoção de respeito mútuo, diálogo inclusivo e harmonia entre os moradores do bairro",
                },
                {
                  title: "Vida em Comunidade",
                  desc: "Fortalecimento dos laços sociais através de atividades coletivas, eventos e espaços de encontro",
                },
                {
                  title: "Desenvolvimento Social",
                  desc: "Melhoria da qualidade de vida, acesso a oportunidades e bem-estar de todos os moradores",
                },
                {
                  title: "Sustentabilidade Ambiental",
                  desc: "Proteção do meio ambiente e promoção de práticas responsáveis para futuras gerações",
                },
                {
                  title: "Participação Democrática",
                  desc: "Garantia de voz ativa para todos os moradores nas decisões que afetam o bairro",
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="group relative bg-gradient-to-br from-gray-900 to-gray-800 p-6 rounded-xl border border-green-900/30 hover:border-green-600/60 transition-all duration-300 transform hover:scale-105"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-green-900/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl -z-10"></div>
                  <h3 className="text-xl font-bold text-white mb-2 group-hover:text-green-400 transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-gray-400 group-hover:text-gray-300 transition-colors">
                    {item.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Bairro de Benevente */}
          <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 border border-green-900/30 rounded-xl p-12">
            <h2 className="text-4xl font-bold text-white mb-6 flex items-center gap-3">
              <Users className="text-green-500" size={40} />
              O Bairro de Benevente
            </h2>
            <p className="text-gray-300 leading-relaxed mb-6">
              Benevente é um bairro localizado em Anchieta, Espírito Santo, caracterizado por uma comunidade acolhedora, tradições fortes e um compromisso com a vida em comum. O nome "Benevente" tem origem no português antigo, significando "bem vindo", refletindo perfeitamente a hospitalidade que caracteriza seus moradores.
            </p>
            <p className="text-gray-300 leading-relaxed mb-6">
              A comunidade de Benevente é conhecida por sua coesão social, respeito mútuo e capacidade de mobilização em torno de objetivos comuns. Anchieta, uma das cidades mais antigas do Espírito Santo, tem em Benevente um de seus bairros mais vibrantes e participativos.
            </p>
            <p className="text-gray-300 leading-relaxed">
              A região é conhecida por sua beleza natural, com praias bucólicas, mangues preservados e uma biodiversidade única no litoral capixaba. Essas características, combinadas com o espírito comunitário de seus moradores, fazem de Benevente um local especial que merece ser protegido, valorizado e desenvolvido de forma sustentável.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
