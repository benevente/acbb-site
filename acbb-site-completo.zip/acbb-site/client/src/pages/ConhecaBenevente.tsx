import { MapPin, Clock, Phone, Trees, Droplet, Users, BookOpen, Anchor } from "lucide-react";

export default function ConhecaBenevente() {
  return (
    <div className="min-h-screen bg-black pt-20">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-gray-900 to-black py-20">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-0 w-96 h-96 bg-green-900 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-green-800 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Conheça Benevente
          </h1>
          <p className="text-xl text-green-300 mb-4">
            Descubra a riqueza natural e cultural do nosso bairro
          </p>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Benevente é um bairro com história, natureza exuberante e patrimônio arqueológico único
          </p>
        </div>
      </section>

      {/* RDS Parque dos Papagaios */}
      <section className="relative bg-black py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Título */}
          <div className="mb-16">
            <h2 className="text-4xl font-bold text-white mb-4 flex items-center gap-3">
              <Trees className="text-green-500" size={36} />
              RDS Parque Sede dos Papagaios
            </h2>
            <p className="text-gray-300 text-lg max-w-3xl">
              Uma unidade de conservação dedicada à proteção do Rio Benevente e das espécies que habitam a região, incluindo o papagaio-do-mangue. O parque protege o manguezal que margeia o rio, um ecossistema vital para a fauna local.
            </p>
          </div>

          {/* Galeria de Fotos */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
            <div className="group relative h-80 rounded-xl overflow-hidden border border-green-900/30 hover:border-green-600/60 transition-all duration-300">
              <img
                src="/parque-entrada.jpg"
                alt="Entrada do Parque"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                <h3 className="text-white font-semibold text-lg">Entrada Principal</h3>
              </div>
            </div>

            <div className="group relative h-80 rounded-xl overflow-hidden border border-green-900/30 hover:border-green-600/60 transition-all duration-300">
              <img
                src="/parque-papagaio.jpg"
                alt="Esculturas do Parque"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                <h3 className="text-white font-semibold text-lg">Esculturas Temáticas</h3>
              </div>
            </div>

            <div className="group relative h-80 rounded-xl overflow-hidden border border-green-900/30 hover:border-green-600/60 transition-all duration-300">
              <img
                src="/parque-playground.jpg"
                alt="Área de Lazer"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                <h3 className="text-white font-semibold text-lg">Área de Lazer</h3>
              </div>
            </div>

            <div className="group relative h-80 rounded-xl overflow-hidden border border-green-900/30 hover:border-green-600/60 transition-all duration-300">
              <img
                src="/parque-vista.jpg"
                alt="Vista Aérea do Parque"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                <h3 className="text-white font-semibold text-lg">Vista Aérea</h3>
              </div>
            </div>
          </div>

          {/* O que fazer no parque */}
          <div className="mb-16">
            <h3 className="text-3xl font-bold text-white mb-8">O que fazer no parque</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  icon: Trees,
                  title: "Trilha",
                  description: "Circuito para caminhada que atravessa o parque em contato com a natureza"
                },
                {
                  icon: Droplet,
                  title: "Mirante",
                  description: "Área de convivência com vista panorâmica da região"
                },
                {
                  icon: Users,
                  title: "Playground",
                  description: "Área de lazer completa para crianças"
                },
                {
                  icon: BookOpen,
                  title: "Academia Popular",
                  description: "Equipamentos para exercícios e atividades físicas"
                },
                {
                  icon: Trees,
                  title: "Viveiro de Mudas",
                  description: "Visita ao viveiro de mudas de árvores nativas"
                },
                {
                  icon: Anchor,
                  title: "Jardim do Mel",
                  description: "Inaugurado em dezembro de 2024, com colmeias de abelhas nativas sem ferrão"
                }
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="bg-gradient-to-br from-gray-900 to-gray-800 p-6 rounded-xl border border-green-900/30 hover:border-green-600/60 transition-all duration-300 group"
                >
                  <item.icon className="text-green-500 mb-4 group-hover:scale-110 transition-transform" size={32} />
                  <h4 className="text-xl font-bold text-white mb-2">{item.title}</h4>
                  <p className="text-gray-300">{item.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Informações Úteis */}
          <div className="bg-gradient-to-r from-green-900/20 to-green-800/10 border border-green-900/30 rounded-xl p-12">
            <h3 className="text-2xl font-bold text-white mb-8">Informações Úteis</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="flex gap-4">
                <MapPin className="text-green-500 flex-shrink-0" size={24} />
                <div>
                  <p className="text-gray-400 text-sm mb-1">Endereço</p>
                  <p className="text-white font-semibold">R. Máximo Gomes Vasco<br/>Bairro Benevente, Anchieta - ES</p>
                </div>
              </div>
              <div className="flex gap-4">
                <Phone className="text-green-500 flex-shrink-0" size={24} />
                <div>
                  <p className="text-gray-400 text-sm mb-1">Telefone</p>
                  <p className="text-white font-semibold">+55 28 99257-6879</p>
                </div>
              </div>
              <div className="flex gap-4">
                <Clock className="text-green-500 flex-shrink-0" size={24} />
                <div>
                  <p className="text-gray-400 text-sm mb-1">Funcionamento</p>
                  <p className="text-white font-semibold">Diariamente de 7h às 18h</p>
                  <p className="text-gray-400 text-xs mt-1">*Recomenda-se ligar para confirmar</p>
                </div>
              </div>
            </div>
            <p className="text-gray-300 mt-8 text-sm">
              <span className="text-green-400 font-semibold">Nota:</span> Para grupos de estudantes é necessário fazer agendamento prévio.
            </p>
          </div>
        </div>
      </section>

      {/* Porto do Mandoca */}
      <section className="relative bg-gradient-to-b from-black to-gray-950 py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Título */}
          <div className="mb-16">
            <h2 className="text-4xl font-bold text-white mb-4 flex items-center gap-3">
              <Anchor className="text-green-500" size={36} />
              Porto do Mandoca
            </h2>
            <p className="text-gray-300 text-lg max-w-3xl">
              Um local histórico e sítio arqueológico em processo de tombamento, situado no bairro Benevente, na cidade de Anchieta, no Espírito Santo.
            </p>
          </div>

          {/* Galeria de Fotos do Mandoca */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
            <div className="group relative h-80 rounded-xl overflow-hidden border border-green-900/30 hover:border-green-600/60 transition-all duration-300">
              <img
                src="/mandoca-aerial.jpg"
                alt="Vista Aérea do Porto do Mandoca"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                <h3 className="text-white font-semibold text-lg">Vista Aérea do Porto</h3>
              </div>
            </div>

            <div className="group relative h-80 rounded-xl overflow-hidden border border-green-900/30 hover:border-green-600/60 transition-all duration-300">
              <img
                src="/mandoca-historico.png"
                alt="Gravura Histórica do Porto do Mandoca"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                <h3 className="text-white font-semibold text-lg">Gravura Histórica</h3>
              </div>
            </div>
          </div>

          {/* Características */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-xl border border-green-900/30">
              <h3 className="text-2xl font-bold text-white mb-4">Sítio Arqueológico</h3>
              <p className="text-gray-300 leading-relaxed mb-4">
                O local abriga um <span className="text-green-400 font-semibold">sambaqui</span>, que é um depósito de conchas e restos de alimentos de antigas comunidades tupiniquins que habitaram a região.
              </p>
              <p className="text-gray-300 leading-relaxed">
                Este sambaqui é reconhecido pelo Instituto do Patrimônio Histórico e Artístico Nacional (IPHAN) e fornece informações valiosas sobre a vida dessas comunidades de até <span className="text-green-400 font-semibold">3.000 anos atrás</span>.
              </p>
            </div>

            <div className="bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-xl border border-green-900/30">
              <h3 className="text-2xl font-bold text-white mb-4">História Local</h3>
              <p className="text-gray-300 leading-relaxed mb-4">
                No passado, o Porto do Mandoca abrigava as <span className="text-green-400 font-semibold">fornalhas primitivas</span> usadas para a produção de cal, que deixaram marcas importantes na história da região.
              </p>
              <p className="text-gray-300 leading-relaxed">
                Hoje, a área permanece como uma comunidade pesqueira tradicional, que enfrenta desafios modernos, como a poluição ambiental, mas mantém viva a tradição e a memória de seus antepassados.
              </p>
            </div>
          </div>

          {/* Rio Benevente */}
          <div className="mb-16">
            <h3 className="text-3xl font-bold text-white mb-8">Rio Benevente</h3>
            <p className="text-gray-300 text-lg mb-8 max-w-3xl">
              O Rio Benevente é o coração natural de nossa região, um ecossistema vital que abriga manguezais preservados, fauna diversa e tradições pesqueiras centenárias. Suas águas cristalinas refletem a beleza intocada da natureza capixaba.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="group relative h-64 rounded-xl overflow-hidden border border-green-900/30 hover:border-green-600/60 transition-all duration-300">
                <img
                  src="/rio-benevente-1.jpg"
                  alt="Manguezal do Rio Benevente"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
                  <h4 className="text-white font-semibold">Manguezal Preservado</h4>
                </div>
              </div>

              <div className="group relative h-64 rounded-xl overflow-hidden border border-green-900/30 hover:border-green-600/60 transition-all duration-300">
                <img
                  src="/rio-benevente-2.jpg"
                  alt="Barco no Rio Benevente"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
                  <h4 className="text-white font-semibold">Tradição Pesqueira</h4>
                </div>
              </div>

              <div className="group relative h-64 rounded-xl overflow-hidden border border-green-900/30 hover:border-green-600/60 transition-all duration-300">
                <img
                  src="/rio-benevente-3.jpg"
                  alt="Vista Aérea do Rio Benevente"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
                  <h4 className="text-white font-semibold">Paisagem Natural</h4>
                </div>
              </div>
            </div>
          </div>

          {/* Importância Cultural */}
          <div className="bg-gradient-to-r from-green-900/20 to-green-800/10 border border-green-900/30 rounded-xl p-12 text-center">
            <h3 className="text-2xl font-bold text-white mb-6">Importância Cultural e Arqueológica</h3>
            <p className="text-gray-300 text-lg max-w-3xl mx-auto leading-relaxed">
              O Porto do Mandoca representa um patrimônio inestimável para a história do Brasil. Como sítio arqueológico, preserva evidências das primeiras ocupações humanas na região, permitindo aos pesquisadores compreender melhor a vida, cultura e tradições das comunidades indígenas que habitaram o litoral capixaba. Sua preservação é fundamental para manter viva a memória coletiva e a identidade cultural de Benevente.
            </p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative bg-black py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-gradient-to-r from-green-900/20 to-green-800/10 border border-green-900/30 rounded-xl p-12">
            <h2 className="text-3xl font-bold text-white mb-4">Visite Benevente</h2>
            <p className="text-gray-300 mb-8 text-lg">
              Descubra a beleza natural, a história rica e a comunidade acolhedora de Benevente
            </p>
            <a
              href="/sobre"
              className="inline-flex items-center gap-2 bg-gradient-to-r from-green-600 to-green-700 text-white px-8 py-3 rounded-lg font-semibold hover:from-green-700 hover:to-green-800 transition-all duration-300 transform hover:scale-105 shadow-2xl"
            >
              Saiba Mais Sobre a ACBB
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
