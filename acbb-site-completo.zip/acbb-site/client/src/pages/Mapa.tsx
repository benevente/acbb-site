import { MapPin, Download, Info } from "lucide-react";

export default function Mapa() {
  return (
    <div className="min-h-screen bg-black pt-20">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-gray-900 to-black py-20">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-0 w-96 h-96 bg-green-900 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-green-800 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Mapa de Benevente
          </h1>
          <p className="text-xl text-green-300 mb-4">
            Localização e Pontos de Interesse
          </p>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Conheça a geografia e os principais pontos de interesse do bairro de Benevente
          </p>
        </div>
      </section>

      {/* Conteúdo Principal */}
      <section className="relative bg-black py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Informações */}
          <div className="mb-20">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl font-bold text-white mb-6 flex items-center gap-3">
                  <MapPin className="text-green-500" size={40} />
                  Localização de Benevente
                </h2>
                <p className="text-gray-300 leading-relaxed mb-4">
                  Benevente é um bairro localizado em Anchieta, Espírito Santo, na região sul do estado. O bairro fica a poucos quilômetros da costa, oferecendo uma localização estratégica com acesso tanto à zona urbana quanto às belezas naturais da região.
                </p>
                <p className="text-gray-300 leading-relaxed mb-4">
                  A região é facilmente acessível por estrada e possui infraestrutura adequada para receber visitantes e moradores. O bairro é conhecido por sua tranquilidade, comunidade acolhedora e patrimônio histórico e natural.
                </p>
                <p className="text-gray-300 leading-relaxed mb-6">
                  Endereço: RDS Parque do Papagaio, s/n, Benevente - CEP 29.230-000 - Anchieta-ES
                </p>
                <a
                  href="/mapa-benevente.pdf"
                  download
                  className="inline-flex items-center gap-2 bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-3 rounded-lg font-semibold hover:from-green-700 hover:to-green-800 transition-all duration-300 transform hover:scale-105 shadow-2xl"
                >
                  <Download size={20} />
                  Baixar Mapa em PDF
                </a>
              </div>
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-green-600/20 to-green-900/20 rounded-xl blur-2xl"></div>
                <img
                  src="/benevente-area.jpg"
                  alt="Vista Aérea de Benevente"
                  className="relative rounded-xl shadow-2xl hover:shadow-green-900/50 transition-shadow duration-300"
                />
              </div>
            </div>
          </div>

          {/* Pontos de Interesse */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold text-white mb-12 text-center">Pontos de Interesse</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                {
                  title: "Centro Comunitário",
                  desc: "Sede da ACBB onde ocorrem reuniões, eventos e atividades comunitárias. Local de referência para a comunidade de Benevente.",
                  icon: "🏢",
                },
                {
                  title: "Porto do Mandoca",
                  desc: "Sítio arqueológico histórico com sambaquis que revelam a importância da região. Patrimônio cultural e natural de grande valor.",
                  icon: "⛵",
                },
                {
                  title: "Praias Locais",
                  desc: "Praias bucólicas com beleza natural única. Ideais para contemplação, pesca artesanal e contato com a natureza.",
                  icon: "🏖️",
                },
                {
                  title: "Mangues Preservados",
                  desc: "Ecossistema costeiro importante para a biodiversidade. Área de preservação ambiental e educação ecológica.",
                  icon: "🌿",
                },
              ].map((ponto, idx) => (
                <div
                  key={idx}
                  className="group relative bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-xl border border-green-900/30 hover:border-green-600/60 transition-all duration-300 transform hover:scale-105"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-green-900/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl -z-10"></div>

                  <div className="text-5xl mb-4">{ponto.icon}</div>
                  <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-green-400 transition-colors">
                    {ponto.title}
                  </h3>
                  <p className="text-gray-400 group-hover:text-gray-300 transition-colors">
                    {ponto.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Visualizador de Mapa */}
          <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 border border-green-900/30 rounded-xl p-12 mb-20">
            <h2 className="text-4xl font-bold text-white mb-6 flex items-center gap-3">
              <Info className="text-green-500" size={40} />
              Visualizar Mapa
            </h2>
            <p className="text-gray-300 mb-8">
              O mapa de Benevente está disponível para download em PDF. Você pode visualizá-lo, imprimir ou compartilhar com outras pessoas. O mapa inclui informações sobre localização, pontos de interesse e infraestrutura do bairro.
            </p>
            <div className="bg-black/50 rounded-lg p-8 text-center">
              <p className="text-gray-400 mb-4">Clique no botão abaixo para visualizar ou baixar o mapa em PDF:</p>
              <a
                href="/mapa-benevente.pdf"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-gradient-to-r from-green-600 to-green-700 text-white px-8 py-4 rounded-lg font-semibold hover:from-green-700 hover:to-green-800 transition-all duration-300 transform hover:scale-105 shadow-2xl"
              >
                <MapPin size={24} />
                Abrir Mapa em PDF
              </a>
            </div>
          </div>

          {/* Como Chegar */}
          <div className="bg-gradient-to-r from-green-900/20 to-green-800/10 border border-green-900/30 rounded-xl p-12">
            <h2 className="text-4xl font-bold text-white mb-8">Como Chegar</h2>
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-green-600 flex items-center justify-center">
                  <span className="text-white font-bold">1</span>
                </div>
                <div>
                  <h3 className="font-bold text-white mb-2 text-lg">De Carro</h3>
                  <p className="text-gray-400">
                    Benevente é facilmente acessível por estrada. Localizado em Anchieta-ES, fica a aproximadamente 50km de Vitória. Use GPS ou o mapa para localizar o Centro Comunitário.
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-green-600 flex items-center justify-center">
                  <span className="text-white font-bold">2</span>
                </div>
                <div>
                  <h3 className="font-bold text-white mb-2 text-lg">Transporte Público</h3>
                  <p className="text-gray-400">
                    Existem linhas de ônibus que conectam Benevente a Anchieta e outras cidades da região. Consulte as empresas de transporte para horários e rotas.
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-green-600 flex items-center justify-center">
                  <span className="text-white font-bold">3</span>
                </div>
                <div>
                  <h3 className="font-bold text-white mb-2 text-lg">Contato</h3>
                  <p className="text-gray-400">
                    Para mais informações sobre como chegar ou visitar Benevente, entre em contato conosco através do telefone (27) 996938845 ou email contato.acbb@outlook.com.br
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
