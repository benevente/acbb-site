import { BookOpen, Calendar, MapPin, Users } from "lucide-react";

export default function Historia() {
  return (
    <div className="min-h-screen bg-black pt-20">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-gray-900 to-black py-20">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-0 w-96 h-96 bg-green-900 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-green-800 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            História da ACBB
          </h1>
          <p className="text-xl text-green-300 mb-4">
            Trajetória de Preservação e Desenvolvimento
          </p>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Conheça a história da Associação Comunitária do Bairro Benevente e seu compromisso com a comunidade
          </p>
        </div>
      </section>

      {/* Conteúdo Principal */}
      <section className="relative bg-black py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Origem e Fundação */}
          <div className="mb-20">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl font-bold text-white mb-6 flex items-center gap-3">
                  <BookOpen className="text-green-500" size={40} />
                  Origem e Fundação
                </h2>
                <p className="text-gray-300 leading-relaxed mb-4">
                  A Associação Comunitária do Bairro Benevente foi fundada com o objetivo de preservar a memória histórica, promover o desenvolvimento social e ambiental da comunidade de Benevente, e valorizar o patrimônio cultural local.
                </p>
                <p className="text-gray-300 leading-relaxed">
                  Nascida da necessidade de documentar e preservar as tradições dos sambaquis e da vida comunitária, a ACBB rapidamente se tornou um espaço importante de articulação e ação coletiva.
                </p>
              </div>
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-green-600/20 to-green-900/20 rounded-xl blur-2xl"></div>
                <img
                  src="/benevente-centro.jpg"
                  alt="Centro Comunitário"
                  className="relative rounded-xl shadow-2xl hover:shadow-green-900/50 transition-shadow duration-300"
                />
              </div>
            </div>
          </div>

          {/* Timeline */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold text-white mb-12 text-center">Marcos Históricos</h2>
            <div className="space-y-8">
              {[
                {
                  year: "Fundação",
                  title: "Criação da ACBB",
                  desc: "Iniciativa comunitária para preservação do patrimônio de Benevente",
                },
                {
                  year: "Primeiros Anos",
                  title: "Documentação e Pesquisa",
                  desc: "Início da documentação da história dos sambaquis e tradições locais",
                },
                {
                  year: "Expansão",
                  title: "Novos Projetos",
                  desc: "Ampliação das atividades para incluir projetos sociais e ambientais",
                },
                {
                  year: "Reconhecimento",
                  title: "Utilidade Pública",
                  desc: "Reconhecimento oficial como Utilidade Pública pela Lei Estadual nº 12.605/2025",
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="group relative bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-xl border border-green-900/30 hover:border-green-600/60 transition-all duration-300 transform hover:scale-105"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-green-900/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl -z-10"></div>

                  <div className="flex gap-4">
                    <Calendar className="text-green-500 flex-shrink-0" size={32} />
                    <div className="flex-1">
                      <p className="text-green-400 font-bold text-sm mb-1">{item.year}</p>
                      <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-green-400 transition-colors">
                        {item.title}
                      </h3>
                      <p className="text-gray-400 group-hover:text-gray-300 transition-colors">
                        {item.desc}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* O Bairro de Benevente */}
          <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 border border-green-900/30 rounded-xl p-12 mb-20">
            <h2 className="text-4xl font-bold text-white mb-6 flex items-center gap-3">
              <MapPin className="text-green-500" size={40} />
              O Bairro de Benevente
            </h2>
            <p className="text-gray-300 leading-relaxed mb-6">
              Benevente é um bairro localizado em Anchieta, Espírito Santo, com uma rica história ligada aos sambaquis - sítios arqueológicos que revelam a importância histórica da região. A região possui características geográficas únicas, com vista para o mar e uma comunidade que mantém fortes tradições culturais.
            </p>
            <p className="text-gray-300 leading-relaxed mb-6">
              O nome "Benevente" tem origem no português antigo, significando "bem vindo", refletindo a hospitalidade e acolhimento que caracterizam a comunidade local. Anchieta, uma das cidades mais antigas do Espírito Santo, tem em Benevente um de seus patrimônios mais valiosos.
            </p>
            <p className="text-gray-300 leading-relaxed">
              A região é conhecida por sua beleza natural, com praias bucólicas, mangues preservados e uma biodiversidade única no litoral capixaba. Essas características fazem de Benevente um local especial que merece ser protegido e valorizado.
            </p>
          </div>

          {/* Os Sambaquis */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold text-white mb-8">Os Sambaquis: Patrimônio Arqueológico</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-xl border border-green-900/30">
                <h3 className="text-2xl font-bold text-white mb-4">O que são Sambaquis</h3>
                <p className="text-gray-300 leading-relaxed">
                  Os sambaquis são sítios arqueológicos formados pelo acúmulo de conchas e resíduos de moluscos, principalmente bugigão. Essas estruturas naturais revelam a história e o modo de vida das populações que habitaram a região há séculos, fornecendo informações valiosas sobre alimentação, técnicas e cultura ancestral.
                </p>
              </div>
              <div className="bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-xl border border-green-900/30">
                <h3 className="text-2xl font-bold text-white mb-4">Importância Histórica</h3>
                <p className="text-gray-300 leading-relaxed">
                  Durante séculos, os sambaquis foram o coração econômico de Benevente, gerando renda e emprego para muitas famílias através da exploração de recursos marinhos. O conhecimento técnico era transmitido de geração em geração, criando uma tradição cultural única que define a identidade de Benevente.
                </p>
              </div>
            </div>
          </div>

          {/* Evolução e Desenvolvimento */}
          <div className="bg-gradient-to-r from-green-900/20 to-green-800/10 border border-green-900/30 rounded-xl p-12">
            <h2 className="text-4xl font-bold text-white mb-8 flex items-center gap-3">
              <Users className="text-green-500" size={40} />
              Evolução e Desenvolvimento
            </h2>
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-green-600 flex items-center justify-center">
                  <span className="text-white font-bold">1</span>
                </div>
                <div>
                  <h3 className="font-bold text-white mb-2 text-lg">Documentação Inicial</h3>
                  <p className="text-gray-400">
                    A ACBB iniciou suas atividades focando na documentação e preservação da história dos sambaquis
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-green-600 flex items-center justify-center">
                  <span className="text-white font-bold">2</span>
                </div>
                <div>
                  <h3 className="font-bold text-white mb-2 text-lg">Expansão de Projetos</h3>
                  <p className="text-gray-400">
                    Com o tempo, a associação expandiu suas ações para incluir projetos sociais, ambientais e educacionais
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-green-600 flex items-center justify-center">
                  <span className="text-white font-bold">3</span>
                </div>
                <div>
                  <h3 className="font-bold text-white mb-2 text-lg">Reconhecimento Oficial</h3>
                  <p className="text-gray-400">
                    Em 2025, a ACBB foi reconhecida como Utilidade Pública, consolidando seu papel na comunidade
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-green-600 flex items-center justify-center">
                  <span className="text-white font-bold">4</span>
                </div>
                <div>
                  <h3 className="font-bold text-white mb-2 text-lg">Futuro Promissor</h3>
                  <p className="text-gray-400">
                    Continuamos expandindo nossos projetos e impacto na comunidade com novos objetivos
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
