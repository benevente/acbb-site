import React, { createContext, useContext, useState, useEffect } from 'react';

interface Noticia {
  id: number;
  titulo: string;
  conteudo: string;
  data: string;
  imagem?: string;
  fonte?: string;
  link?: string;
}

interface Membro {
  id: number;
  nome: string;
  cargo: string;
  descricao: string;
  foto?: string;
}

interface DespesaCategory {
  id: number;
  categoria: string;
  valor: number;
  percentual: number;
}

interface FonteReceita {
  id: number;
  fonte: string;
  valor: number;
  data: string;
}

interface Lancamento {
  id: number;
  data: string;
  tipo: 'receita' | 'despesa';
  descricao: string;
  categoria: string;
  valor: number;
  observacoes?: string;
}

interface Documento {
  id: number;
  nome: string;
  descricao: string;
  arquivo: string;
  tipo: string;
  dataUpload: string;
  tamanho?: number;
}

interface OuvidoriaPedido {
  id: number;
  protocolo: string;
  categoria: string;
  nome: string;
  email: string;
  telefone: string;
  assunto: string;
  descricao: string;
  anexo?: string;
  nomeAnexo?: string;
  data: string;
  status: string;
  resposta?: string;
  dataResposta?: string;
}

interface SiteData {
  // Informações gerais
  nomeAssociacao: string;
  descricaoBreve: string;
  endereco: string;
  telefone: string;
  email: string;
  cnpj: string;
  missao: string;
  visao: string;
  valores: string;

  // Homepage
  homeHeroTitle: string;
  homeHeroSubtitle: string;
  homeHeroDescription: string;
  homeInfoDescription: string;

  // Sobre
  sobreContent: string;
  sobreHeroTitle: string;
  sobreHeroSubtitle: string;
  sobreHeroDescription: string;
  sobreFundacaoContent: string;
  sobreMissao: string;
  sobreVisao: string;
  sobreValores: string;

  // Conheça Benevente
  conhecaContent: string;
  conhecaHeroTitle: string;
  conhecaHeroSubtitle: string;
  conhecaHeroDescription: string;

  // Mapa
  mapaContent: string;
  mapaHeroTitle: string;
  mapaHeroSubtitle: string;

  // Estatuto
  estatutoContent: string;
  estatutoHeroTitle: string;
  estatutoHeroSubtitle: string;

  // Transparência
  transparenciaTitulo: string;
  transparenciaDescricao: string;
  transparenciaContent: string;
  receitaTotal: number;
  despesasTotal: number;
  saldo: number;
  anoFinanceiro: string;
  despesasCategories: DespesaCategory[];
  fontesReceita: FonteReceita[];

  // Sistema Contábil
  lancamentos: Lancamento[];
  documentos: Documento[];

  // Ouvidoria
  ouvidoriaPedidos: OuvidoriaPedido[];

  // Notícias e Membros
  noticias: Noticia[];
  diretoria: Membro[];
}

interface SiteContextType {
  siteData: SiteData;
  updateSiteData: (updates: Partial<SiteData>) => void;
  addNoticia: (noticia: Noticia) => void;
  updateNoticia: (id: number, updates: Partial<Noticia>) => void;
  deleteNoticia: (id: number) => void;
  addMembro: (membro: Membro) => void;
  updateMembro: (id: number, updates: Partial<Membro>) => void;
  deleteMembro: (id: number) => void;
  addDespesaCategory: (category: DespesaCategory) => void;
  updateDespesaCategory: (id: number, updates: Partial<DespesaCategory>) => void;
  deleteDespesaCategory: (id: number) => void;
  addFonteReceita: (fonte: FonteReceita) => void;
  updateFonteReceita: (id: number, updates: Partial<FonteReceita>) => void;
  deleteFonteReceita: (id: number) => void;
  addLancamento: (lancamento: Lancamento) => void;
  updateLancamento: (id: number, updates: Partial<Lancamento>) => void;
  deleteLancamento: (id: number) => void;
  addDocumento: (documento: Documento) => void;
  deleteDocumento: (id: number) => void;
  addOuvidoriaPedido: (pedido: OuvidoriaPedido) => void;
  updateOuvidoriaPedido: (id: number, updates: Partial<OuvidoriaPedido>) => void;
  deleteOuvidoriaPedido: (id: number) => void;
  saveToLocalStorage: () => void;
}

const DEFAULT_SITE_DATA: SiteData = {
  // Informações gerais
  nomeAssociacao: 'Associação Comunitária do Bairro Benevente',
  descricaoBreve: 'Preservando Tradições, Construindo Futuro',
  endereco: 'RDS Parque do Papagaio, s/n, Benevente - CEP 29.230-000 - Anchieta-ES',
  telefone: '(27) 996938845',
  email: 'contato.acbb@outlook.com.br',
  cnpj: '50.477.436/0001-44',
  missao: 'Fortalecer a comunidade de Benevente através da promoção de cultura, boa convivência, desenvolvimento social e ambiental, defendendo os interesses coletivos e promovendo cidadania ativa.',
  visao: 'Ser referência em mobilização comunitária, criando um bairro onde a cultura é valorizada, a convivência é harmoniosa, e todos têm voz ativa nas decisões que afetam suas vidas.',
  valores: 'Solidariedade, transparência, inclusão, respeito à diversidade, democracia participativa e compromisso genuíno com o bem-estar coletivo.',

  // Homepage
  homeHeroTitle: 'Associação Comunitária do Bairro Benevente',
  homeHeroSubtitle: 'Preservando Tradições, Construindo Futuro',
  homeHeroDescription: 'Reconhecida como Utilidade Pública pela Lei Estadual nº 12.605/2025',
  homeInfoDescription: 'Conectando a comunidade de Benevente através de ações sustentáveis e preservação cultural',

  // Sobre
  sobreContent: '',
  sobreHeroTitle: 'Sobre a ACBB',
  sobreHeroSubtitle: 'Associação Comunitária do Bairro Benevente',
  sobreHeroDescription: 'Unindo pessoas em torno da cultura, boa convivência e desenvolvimento comunitário',
  sobreFundacaoContent: 'A Associação Comunitária do Bairro Benevente foi fundada com o objetivo de fortalecer os laços comunitários, promover a cultura local, defender os interesses dos moradores e contribuir para o desenvolvimento sustentável do bairro.',
  sobreMissao: 'Fortalecer a comunidade de Benevente através da promoção de cultura, boa convivência, desenvolvimento social e ambiental, defendendo os interesses coletivos e promovendo cidadania ativa.',
  sobreVisao: 'Ser referência em mobilização comunitária, criando um bairro onde a cultura é valorizada, a convivência é harmoniosa, e todos têm voz ativa nas decisões que afetam suas vidas.',
  sobreValores: 'Solidariedade, transparência, inclusão, respeito à diversidade, democracia participativa e compromisso genuíno com o bem-estar coletivo.',

  // Conheça Benevente
  conhecaContent: 'Conheça Benevente',
  conhecaHeroTitle: 'Conheça Benevente',
  conhecaHeroSubtitle: 'Um Bairro Cheio de História',
  conhecaHeroDescription: 'Descubra a beleza natural e cultural de Benevente',

  // Mapa
  mapaContent: 'Mapa de Benevente',
  mapaHeroTitle: 'Mapa de Benevente',
  mapaHeroSubtitle: 'Localização e Pontos de Interesse',

  // Estatuto
  estatutoContent: 'Conteúdo do Estatuto',
  estatutoHeroTitle: 'Estatuto da ACBB',
  estatutoHeroSubtitle: 'Regulamento Interno',

  // Transparência
  transparenciaTitulo: 'Portal de Transparência',
  transparenciaDescricao: 'Informações financeiras e prestação de contas',
  transparenciaContent: 'Conteúdo da Transparência',
  receitaTotal: 48000,
  despesasTotal: 43000,
  saldo: 5000,
  anoFinanceiro: '2025',
  
  despesasCategories: [
    { id: 1, categoria: 'Projetos Sociais', valor: 15000, percentual: 35 },
    { id: 2, categoria: 'Educação Ambiental', valor: 10000, percentual: 23 },
    { id: 3, categoria: 'Preservação Patrimonial', valor: 12000, percentual: 28 },
    { id: 4, categoria: 'Administração', valor: 6000, percentual: 14 },
  ],
  
  fontesReceita: [
    { id: 1, fonte: 'Doações', valor: 25000, data: '2025' },
    { id: 2, fonte: 'Parcerias', valor: 15000, data: '2025' },
    { id: 3, fonte: 'Eventos', valor: 8000, data: '2025' },
  ],

  // Sistema Contábil
  lancamentos: [
    {
      id: 1,
      data: '2025-01-15',
      tipo: 'receita',
      descricao: 'Doação de membro',
      categoria: 'Doações',
      valor: 500,
      observacoes: 'Doação voluntária'
    },
    {
      id: 2,
      data: '2025-01-20',
      tipo: 'despesa',
      descricao: 'Material para evento',
      categoria: 'Projetos Sociais',
      valor: 300,
      observacoes: 'Compra de materiais'
    }
  ],

  documentos: [
    {
      id: 1,
      nome: 'Relatório Financeiro 2025',
      descricao: 'Detalhamento completo de receitas e despesas',
      arquivo: '',
      tipo: 'PDF',
      dataUpload: '2025-01-01'
    }
  ],

  ouvidoriaPedidos: [],

  noticias: [
    {
      id: 1,
      titulo: 'MPES requer que CESAN seja condenada a reparar poluição ambiental no Rio Benevente em Anchieta',
      conteudo: 'O Ministério Público do Espírito Santo (MPES) requereu que a Companhia Espírito Santense de Saneamento (CESAN) seja condenada a reparar os danos ambientais causados pela poluição no Rio Benevente. A ação busca garantir a recuperação e preservação deste importante ecossistema que é fundamental para a comunidade de Benevente e para toda a região de Anchieta.',
      data: '04 de novembro de 2025',
      imagem: '/rio-poluicao.jpg',
      fonte: 'Ministério Público do Espírito Santo (MPES)',
      link: 'https://mpes.mp.br/noticias/2025/11/04/mpes-requer-que-cesan-seja-condenada-a-reparar-poluicao-ambiental-no-rio-benevente-em-anchieta/'
    }
  ],

  diretoria: [
    {
      id: 1,
      nome: 'João Simas',
      cargo: 'Presidente',
      descricao: 'Liderança dedicada ao desenvolvimento comunitário e preservação do patrimônio cultural de Benevente.',
    },
    {
      id: 2,
      nome: 'Weligton Batista',
      cargo: 'Vice-Presidente',
      descricao: 'Apoio na coordenação de projetos e iniciativas da associação.',
    },
    {
      id: 3,
      nome: 'Adenir Faria',
      cargo: 'Tesoureira',
      descricao: 'Responsável pela gestão financeira e transparência da associação.',
    },
    {
      id: 4,
      nome: 'Aline Sezini',
      cargo: 'Conselho Fiscal',
      descricao: 'Fiscalização e acompanhamento das atividades da associação.',
    },
    {
      id: 5,
      nome: 'Jadir Purcino',
      cargo: 'Conselho Fiscal',
      descricao: 'Fiscalização e acompanhamento das atividades da associação.',
    }
  ],
};;

const SiteContext = createContext<SiteContextType | undefined>(undefined);

// Função auxiliar para calcular totais automaticamente
function calcularTotaisAutomaticos(lancamentos: Lancamento[]) {
  let receitaTotal = 0;
  let despesasTotal = 0;

  lancamentos.forEach(lancamento => {
    if (lancamento.tipo === 'receita') {
      receitaTotal += lancamento.valor;
    } else {
      despesasTotal += lancamento.valor;
    }
  });

  const saldo = receitaTotal - despesasTotal;

  return { receitaTotal, despesasTotal, saldo };
}

export function SiteProvider({ children }: { children: React.ReactNode }) {
  const [siteData, setSiteData] = useState<SiteData>(DEFAULT_SITE_DATA);

  // Carregar dados do localStorage ao iniciar\n  // Função para simular a busca de notícias de uma API externa (automação)\n  const fetchNews = async () => {\n    // Simulação de chamada de API\n    const newNews: Noticia[] = [\n      {\n        id: 2,\n        titulo: 'ACBB Lança Campanha de Conscientização Ambiental',\n        conteudo: 'A Associação Comunitária do Bairro Benevente lançou uma nova campanha focada na preservação do Rio Benevente e na coleta seletiva. A iniciativa visa educar a população sobre a importância da sustentabilidade e do descarte correto de resíduos.',\n        data: new Date().toLocaleDateString('pt-BR'),\n        imagem: '/campanha-ambiental.jpg',\n        fonte: 'ACBB',\n        link: '/noticias'\n      },\n      {\n        id: 3,\n        titulo: 'Reunião de Diretoria Define Novas Metas para o Trimestre',\n        conteudo: 'Em reunião realizada na última semana, a diretoria da ACBB definiu as prioridades para o próximo trimestre, focando em projetos sociais e na busca por novas parcerias para o desenvolvimento do bairro.',\n        data: new Date().toLocaleDateString('pt-BR'),\n        imagem: '/reuniao-diretoria.jpg',\n        fonte: 'ACBB',\n        link: '/noticias'\n      }\n    ];\n\n    // Atualiza apenas se as notícias ainda não existirem (para não duplicar)\n    setSiteData(prev => {\n      const existingIds = new Set(prev.noticias.map(n => n.id));\n      const filteredNewNews = newNews.filter(n => !existingIds.has(n.id));\n      \n      if (filteredNewNews.length > 0) {\n        return { ...prev, noticias: [...prev.noticias, ...filteredNewNews] };\n      }\n      return prev;\n    });\n  };\n\n  // Efeito para buscar notícias a cada 24 horas (simulação de automação)\n  useEffect(() => {\n    fetchNews();\n    const interval = setInterval(fetchNews, 24 * 60 * 60 * 1000); // 24 horas\n    return () => clearInterval(interval);\n  }, []);\n\n  // Carregar dados do localStorage ao iniciar
  useEffect(() => {
    const saved = localStorage.getItem('acbb_site_data');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setSiteData({ ...DEFAULT_SITE_DATA, ...parsed });
      } catch (e) {
        console.error('Erro ao carregar dados:', e);
      }
    }
  }, []);

  const updateSiteData = (updates: Partial<SiteData>) => {
    setSiteData(prev => ({ ...prev, ...updates }));
  };

  const addNoticia = (noticia: Noticia) => {
    setSiteData(prev => ({
      ...prev,
      noticias: [...prev.noticias, noticia]
    }));
  };

  const updateNoticia = (id: number, updates: Partial<Noticia>) => {
    setSiteData(prev => ({
      ...prev,
      noticias: prev.noticias.map(n => n.id === id ? { ...n, ...updates } : n)
    }));
  };

  const deleteNoticia = (id: number) => {
    setSiteData(prev => ({
      ...prev,
      noticias: prev.noticias.filter(n => n.id !== id)
    }));
  };

  const addMembro = (membro: Membro) => {
    setSiteData(prev => ({
      ...prev,
      diretoria: [...prev.diretoria, membro]
    }));
  };

  const updateMembro = (id: number, updates: Partial<Membro>) => {
    setSiteData(prev => ({
      ...prev,
      diretoria: prev.diretoria.map(m => m.id === id ? { ...m, ...updates } : m)
    }));
  };

  const deleteMembro = (id: number) => {
    setSiteData(prev => ({
      ...prev,
      diretoria: prev.diretoria.filter(m => m.id !== id)
    }));
  };

  const addDespesaCategory = (category: DespesaCategory) => {
    setSiteData(prev => ({
      ...prev,
      despesasCategories: [...prev.despesasCategories, category]
    }));
  };

  const updateDespesaCategory = (id: number, updates: Partial<DespesaCategory>) => {
    setSiteData(prev => ({
      ...prev,
      despesasCategories: prev.despesasCategories.map(c => c.id === id ? { ...c, ...updates } : c)
    }));
  };

  const deleteDespesaCategory = (id: number) => {
    setSiteData(prev => ({
      ...prev,
      despesasCategories: prev.despesasCategories.filter(c => c.id !== id)
    }));
  };

  const addFonteReceita = (fonte: FonteReceita) => {
    setSiteData(prev => ({
      ...prev,
      fontesReceita: [...prev.fontesReceita, fonte]
    }));
  };

  const updateFonteReceita = (id: number, updates: Partial<FonteReceita>) => {
    setSiteData(prev => ({
      ...prev,
      fontesReceita: prev.fontesReceita.map(f => f.id === id ? { ...f, ...updates } : f)
    }));
  };

  const deleteFonteReceita = (id: number) => {
    setSiteData(prev => ({
      ...prev,
      fontesReceita: prev.fontesReceita.filter(f => f.id !== id)
    }));
  };

  // Sistema Contábil com Cálculos Automáticos
  const addLancamento = (lancamento: Lancamento) => {
    setSiteData(prev => {
      const novoLancamento = {
        ...lancamento,
        id: Math.max(...prev.lancamentos.map(l => l.id), 0) + 1
      };
      const novaLista = [...prev.lancamentos, novoLancamento];
      const { receitaTotal, despesasTotal, saldo } = calcularTotaisAutomaticos(novaLista);
      
      return {
        ...prev,
        lancamentos: novaLista,
        receitaTotal,
        despesasTotal,
        saldo
      };
    });
  };

  const updateLancamento = (id: number, updates: Partial<Lancamento>) => {
    setSiteData(prev => {
      const novaLista = prev.lancamentos.map(l => l.id === id ? { ...l, ...updates } : l);
      const { receitaTotal, despesasTotal, saldo } = calcularTotaisAutomaticos(novaLista);
      
      return {
        ...prev,
        lancamentos: novaLista,
        receitaTotal,
        despesasTotal,
        saldo
      };
    });
  };

  const deleteLancamento = (id: number) => {
    setSiteData(prev => {
      const novaLista = prev.lancamentos.filter(l => l.id !== id);
      const { receitaTotal, despesasTotal, saldo } = calcularTotaisAutomaticos(novaLista);
      
      return {
        ...prev,
        lancamentos: novaLista,
        receitaTotal,
        despesasTotal,
        saldo
      };
    });
  };

  // Gestão de Documentos
  const addDocumento = (documento: Documento) => {
    setSiteData(prev => ({
      ...prev,
      documentos: [...prev.documentos, {
        ...documento,
        id: Math.max(...prev.documentos.map(d => d.id), 0) + 1
      }]
    }));
  };

  const deleteDocumento = (id: number) => {
    setSiteData(prev => ({
      ...prev,
      documentos: prev.documentos.filter(d => d.id !== id)
    }));
  };

  // Gestão de Ouvidoria
  const addOuvidoriaPedido = (pedido: OuvidoriaPedido) => {
    setSiteData(prev => ({
      ...prev,
      ouvidoriaPedidos: [...prev.ouvidoriaPedidos, {
        ...pedido,
        id: Math.max(...prev.ouvidoriaPedidos.map(p => p.id), 0) + 1
      }]
    }));
  };

  const updateOuvidoriaPedido = (id: number, updates: Partial<OuvidoriaPedido>) => {
    setSiteData(prev => ({
      ...prev,
      ouvidoriaPedidos: prev.ouvidoriaPedidos.map(p => p.id === id ? { ...p, ...updates } : p)
    }));
  };

  const deleteOuvidoriaPedido = (id: number) => {
    setSiteData(prev => ({
      ...prev,
      ouvidoriaPedidos: prev.ouvidoriaPedidos.filter(p => p.id !== id)
    }));
  };

  const saveToLocalStorage = () => {
    localStorage.setItem('acbb_site_data', JSON.stringify(siteData));
  };

  return (
    <SiteContext.Provider
      value={{
        siteData,
        updateSiteData,
        addNoticia,
        updateNoticia,
        deleteNoticia,
        addMembro,
        updateMembro,
        deleteMembro,
        addDespesaCategory,
        updateDespesaCategory,
        deleteDespesaCategory,
        addFonteReceita,
        updateFonteReceita,
        deleteFonteReceita,
        addLancamento,
        updateLancamento,
        deleteLancamento,
        addDocumento,
        deleteDocumento,
        addOuvidoriaPedido,
        updateOuvidoriaPedido,
        deleteOuvidoriaPedido,
        saveToLocalStorage,
      }}
    >
      {children}
    </SiteContext.Provider>
  );
}

export function useSiteContext() {
  const context = useContext(SiteContext);
  if (!context) {
    throw new Error('useSiteContext deve ser usado dentro de SiteProvider');
  }
  return context;
}
