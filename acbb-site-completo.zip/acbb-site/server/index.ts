import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";
import nodemailer from "nodemailer";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Configuração do transportador de e-mail
const transporter = nodemailer.createTransport({
  host: "smtp-mail.outlook.com",
  port: 587,
  secure: false, // true para 465, false para outras portas
  auth: {
    user: "contato.acbb@outlook.com.br",
    pass: "ACBB2025.",
  },
});

// Função para carregar e processar templates HTML
function loadTemplate(templateName: string, data: Record<string, string>): string {
  const templatePath = path.join(__dirname, "..", "server", "email-templates", `${templateName}.html`);
  let template = fs.readFileSync(templatePath, "utf-8");
  
  // Substituir placeholders no template
  Object.keys(data).forEach((key) => {
    const regex = new RegExp(`{{${key}}}`, "g");
    template = template.replace(regex, data[key]);
  });
  
  return template;
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Middleware para parsear JSON
  app.use(express.json());

  // Serve static files from dist/public in production
  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");

  app.use(express.static(staticPath));

  // API para enviar e-mails da Ouvidoria
  app.post("/api/enviar-email-ouvidoria", async (req, res) => {
    try {
      const { protocolo, categoria, nome, email, telefone, assunto, descricao, data } = req.body;

      // Validar dados
      if (!protocolo || !categoria || !nome || !email || !assunto || !descricao) {
        return res.status(400).json({ error: "Dados incompletos" });
      }

      const baseUrl = `${req.protocol}://${req.get("host")}`;

      // Dados para os templates
      const templateData = {
        protocolo,
        categoria: categoria.toUpperCase(),
        nome,
        email,
        telefone: telefone || "Não informado",
        assunto,
        descricao,
        data: data || new Date().toLocaleDateString("pt-BR"),
        link_gestao: `${baseUrl}/gestao`,
        link_consulta: `${baseUrl}/ouvidoria`,
        link_site: baseUrl,
      };

      // Carregar templates
      const htmlACBB = loadTemplate("notificacao-acbb", templateData);
      const htmlCidadao = loadTemplate("confirmacao-cidadao", templateData);

      // Enviar e-mail para a ACBB
      await transporter.sendMail({
        from: '"Ouvidoria ACBB" <contato.acbb@outlook.com.br>',
        to: "contato.acbb@outlook.com.br",
        subject: `[OUVIDORIA] Novo Pedido - ${categoria.toUpperCase()} - Protocolo ${protocolo}`,
        html: htmlACBB,
      });

      // Enviar e-mail de confirmação para o cidadão
      await transporter.sendMail({
        from: '"Ouvidoria ACBB" <contato.acbb@outlook.com.br>',
        to: email,
        subject: `Confirmação de Recebimento - Protocolo ${protocolo}`,
        html: htmlCidadao,
      });

      res.json({ success: true, message: "E-mails enviados com sucesso" });
    } catch (error) {
      console.error("Erro ao enviar e-mails:", error);
      res.status(500).json({ error: "Erro ao enviar e-mails" });
    }
  });

  // Handle client-side routing - serve index.html for all routes
  app.get("*", (_req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
  });

  const port = process.env.PORT || 3000;

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
