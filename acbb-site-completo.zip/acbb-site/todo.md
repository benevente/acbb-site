# ACBB Website - TODO

## Preparação e Assets
- [x] Copiar e otimizar logo ACBB
- [x] Processar fotos do bairro (IMG_8636, IMG_8635)
- [x] Extrair conteúdo do PDF do estatuto
- [x] Extrair conteúdo do PDF do mapa
- [x] Processar fotos da diretoria

## Estrutura e Navegação
- [x] Criar layout base com header e footer
- [x] Implementar navegação principal (Home, Notícias, Sobre, SOS Mandoca, História, Estatuto, Diretoria, Transparência)
- [x] Criar sistema de roteamento multi-página

## Página Inicial
- [x] Hero section com logo ACBB
- [x] Seção de informações da associação (endereço, telefone, email, CNPJ)
- [x] Destaque para reconhecimento de utilidade pública
- [x] Seção de fotos do bairro
- [x] CTA para notícias e SOS Mandoca

## Sistema de Notícias
- [x] Criar página de notícias
- [x] Implementar login (ACBB1996 / 12091996)
- [x] Criar interface de edição de notícias
- [x] Armazenar notícias (localStorage ou banco de dados)
- [x] Exibir notícias com data e autor

## Páginas de Conteúdo
- [x] Página "Sobre" com descrição da ACBB
- [x] Página "SOS Mandoca" com informações do projeto
- [x] Página "História da ACBB" com contexto histórico
- [x] Página "Estatuto" com visualização/download do PDF

## Portal de Transparência
- [x] Criar página de prestação de contas
- [x] Exibir informações financeiras
- [x] Criar tabela de receitas e despesas
- [x] Adicionar documentos de transparência

## Página de Diretoria
- [x] Exibir perfis dos membros:
  - João Simas (Presidente)
  - Weligton Batista (Vice)
  - Adenir Faria (Tesoureira)
  - Aline Sezini (Conselho Fiscal)
  - Jadir Purcino (Conselho Fiscal)
- [x] Adicionar fotos dos membros
- [x] Adicionar descrições dos membros

## Design e Responsividade
- [x] Design moderno com paleta de cores verde (ACBB)
- [x] Responsividade mobile-first
- [x] Efeitos visuais e transições suaves
- [x] Footer com informações de contato

## Painel de Gestão 100% Editável
- [x] Criar SiteContext global com estrutura completa de dados
- [x] Implementar painel de gestão com 9 abas estruturadas
- [x] Edição de Home (título, subtítulo, descrição hero)
- [x] Edição de Sobre (hero, fundação, missão, visão, valores)
- [x] Edição de SOS Mandoca (hero section)
- [x] Edição de Conheça Benevente (conteúdo completo)
- [x] Edição de Mapa (conteúdo)
- [x] Edição de Estatuto (conteúdo)
- [x] Edição de Diretoria (CRUD de membros)
- [x] Edição de Transparência (valores financeiros, categorias, fontes)
- [x] Edição de Notícias (CRUD com upload de imagens)
- [x] Sincronização em tempo real de todas as páginas
- [x] Persistência de dados em localStorage

## Testes e Finalização
- [x] Testar navegação em todas as páginas
- [x] Verificar responsividade em dispositivos móveis
- [x] Testar sistema de login
- [x] Ajustes finais de design
- [x] Testar painel de gestão com edições em tempo real
- [x] Verificar sincronização de dados entre páginas
- [ ] Deploy e publicação

## Sistema Contábil Automático
- [x] Expandir SiteContext com estrutura de lançamentos contábeis
- [x] Criar aba "Lançamentos" no painel para registrar transações
- [x] Implementar cálculos automáticos (saldo, receita, despesas, percentuais)
- [x] Criar aba "Documentos" para upload e gerenciamento de arquivos
- [x] Sincronizar página de Transparência com lançamentos automáticos
- [x] Testar sistema contábil completo

## Sistema de Ouvidoria
- [x] Expandir SiteContext com estrutura de Ouvidoria (pedidos, categorias, protocolos)
- [x] Remover SOS Mandoca do site e painel
- [x] Criar página de Ouvidoria com 6 categorias (Sugestão, Reclamação, Solicitação, Denúncia, Informação, Elogio)
- [x] Implementar formulário de Ouvidoria com upload de anexos
- [x] Gerar protocolo automático para cada pedido
- [x] Criar aba de Ouvidoria no painel de gestão
- [x] Implementar resposta de pedidos no painel
- [x] Sincronizar página de Ouvidoria com respostas
- [x] Testar sistema de Ouvidoria completo
