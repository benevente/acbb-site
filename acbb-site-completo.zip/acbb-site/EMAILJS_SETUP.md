# Configuração do EmailJS para Envio de E-mails da Ouvidoria

Este documento explica como configurar o **EmailJS** para permitir o envio automático de e-mails quando um pedido é enviado pela Ouvidoria.

## Passo 1: Criar uma Conta no EmailJS

1. Acesse [https://www.emailjs.com/](https://www.emailjs.com/)
2. Clique em **Sign Up** e crie uma conta gratuita
3. Confirme seu e-mail

## Passo 2: Adicionar um Serviço de E-mail

1. No painel do EmailJS, clique em **Email Services**
2. Clique em **Add New Service**
3. Escolha o provedor de e-mail (recomendado: **Gmail** ou **Outlook**)
4. Siga as instruções para conectar sua conta de e-mail
5. Anote o **Service ID** gerado (ex: `service_abc123`)

## Passo 3: Criar Templates de E-mail

### Template 1: Notificação para a ACBB

1. No painel do EmailJS, clique em **Email Templates**
2. Clique em **Create New Template**
3. Configure o template com as seguintes informações:

**Nome do Template:** `Novo Pedido - Ouvidoria ACBB`

**To Email:** `{{to_email_acbb}}`

**Subject:** `[OUVIDORIA] Novo Pedido - {{categoria}} - Protocolo {{protocolo}}`

**Content:**
```
Olá, equipe ACBB!

Um novo pedido foi recebido pela Ouvidoria:

PROTOCOLO: {{protocolo}}
CATEGORIA: {{categoria}}
DATA: {{data}}

DADOS DO SOLICITANTE:
Nome: {{nome}}
E-mail: {{email}}
Telefone: {{telefone}}

ASSUNTO: {{assunto}}

DESCRIÇÃO:
{{descricao}}

---
Acesse o Painel de Gestão para responder a este pedido.
```

4. Salve o template e anote o **Template ID** (ex: `template_xyz789`)

### Template 2: Confirmação para o Cidadão

1. Crie um segundo template
2. Configure com as seguintes informações:

**Nome do Template:** `Confirmação de Pedido - Ouvidoria ACBB`

**To Email:** `{{to_email_cidadao}}`

**Subject:** `Confirmação de Recebimento - Protocolo {{protocolo}}`

**Content:**
```
Olá, {{nome}}!

Seu pedido foi recebido com sucesso pela Ouvidoria da ACBB.

PROTOCOLO: {{protocolo}}
CATEGORIA: {{categoria}}
DATA: {{data}}

ASSUNTO: {{assunto}}

Você pode acompanhar o status do seu pedido através do nosso site, usando o número do protocolo acima.

Agradecemos o seu contato!

---
Associação Comunitária do Bairro Benevente
E-mail: contato.acbb@outlook.com.br
```

3. Salve o template e anote o **Template ID** (ex: `template_abc456`)

## Passo 4: Obter a Public Key

1. No painel do EmailJS, clique em **Account**
2. Na seção **API Keys**, copie a **Public Key** (ex: `user_1234567890abcdef`)

## Passo 5: Atualizar o Código

Abra o arquivo `client/src/pages/Ouvidoria.tsx` e substitua os seguintes valores:

```typescript
// Linha 102-105 (E-mail para a ACBB)
emailjs.send(
  'YOUR_SERVICE_ID',         // Substitua pelo Service ID (ex: 'service_abc123')
  'YOUR_TEMPLATE_ID_ACBB',   // Substitua pelo Template ID da ACBB (ex: 'template_xyz789')
  emailParams,
  'YOUR_PUBLIC_KEY'          // Substitua pela Public Key (ex: 'user_1234567890abcdef')
)

// Linha 112-115 (E-mail para o Cidadão)
emailjs.send(
  'YOUR_SERVICE_ID',         // Substitua pelo Service ID (ex: 'service_abc123')
  'YOUR_TEMPLATE_ID_CIDADAO', // Substitua pelo Template ID do Cidadão (ex: 'template_abc456')
  emailParams,
  'YOUR_PUBLIC_KEY'          // Substitua pela Public Key (ex: 'user_1234567890abcdef')
)
```

## Passo 6: Testar

1. Reconstrua o projeto: `pnpm run build`
2. Inicie o servidor: `pnpm run start`
3. Acesse a página da Ouvidoria e envie um pedido de teste
4. Verifique se os e-mails foram recebidos tanto pela ACBB quanto pelo cidadão

## Observações

- A conta gratuita do EmailJS permite **200 e-mails por mês**
- Se precisar de mais e-mails, considere fazer upgrade para um plano pago
- Certifique-se de que o e-mail `contato.acbb@outlook.com.br` está correto

## Suporte

Se tiver dúvidas, consulte a documentação oficial do EmailJS: [https://www.emailjs.com/docs/](https://www.emailjs.com/docs/)
